
  # IASTest (V2)

  This is a code bundle for IASTest (V2). The original project is available at https://www.figma.com/design/8CaXnOkB1MhnQDKkbTCtcn/IASTest--V2-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  