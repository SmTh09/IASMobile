# 🔒 Firestore Security Rules Setup

## ⚠️ CRITICAL: Fix Permission Denied Error

If you're seeing `[code=permission-denied]: Missing or insufficient permissions`, you need to update your Firestore Security Rules.

## Quick Fix (For Development/Testing)

### Step 1: Go to Firebase Console
Visit: https://console.firebase.google.com/project/mobileias/firestore/rules

### Step 2: Update Security Rules

Replace the entire content with this **TEST MODE** configuration:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // TEST MODE - Allow all read/write operations
    // ⚠️ WARNING: This is NOT secure for production!
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

### Step 3: Click "Publish"

That's it! Your app will now work.

---

## 🛡️ Production Security Rules (Recommended)

Once your app is working, replace with these more secure rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Appointments collection
    match /appointments/{appointmentId} {
      // Anyone can read appointments
      allow read: if true;
      
      // Anyone can create appointments
      allow create: if true;
      
      // Anyone can update appointments (you can restrict this later)
      allow update: if true;
      
      // Anyone can delete appointments (you can restrict this later)
      allow delete: if true;
    }
    
    // Appointment counts collection
    match /appointmentCounts/{customerId} {
      // Anyone can read counts
      allow read: if true;
      
      // Anyone can write counts
      allow write: if true;
    }
    
    // Parts Relocation Collections
    
    // Physical locations - read-only for most users
    match /physicalLocations/{locationId} {
      allow read: if true;
      allow write: if true; // Restrict to admins in production
    }
    
    // Shelves - read-only for most users
    match /shelves/{shelfId} {
      allow read: if true;
      allow write: if true; // Restrict to admins in production
    }
    
    // Parts - read/write for inventory management
    match /parts/{partId} {
      allow read: if true;
      allow write: if true;
    }
    
    // Relocations - read/write for users
    match /relocations/{relocationId} {
      allow read: if true;
      allow create: if true;
      allow update: if true;
      allow delete: if true; // Restrict to admins in production
    }
  }
}
```

---

## 🔐 Enterprise Security Rules (With Authentication)

If you implement Firebase Authentication later:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper function to check if user is authenticated
    function isAuthenticated() {
      return request.auth != null;
    }
    
    // Helper function to check if user owns the resource
    function isOwner(customerId) {
      return isAuthenticated() && request.auth.uid == customerId;
    }
    
    // Appointments collection
    match /appointments/{appointmentId} {
      // Authenticated users can read their own appointments
      allow read: if isAuthenticated();
      
      // Users can only create appointments for themselves
      allow create: if isAuthenticated() && 
                      request.resource.data.customerId == request.auth.uid;
      
      // Users can only update their own appointments
      allow update: if isAuthenticated() && 
                      resource.data.customerId == request.auth.uid;
      
      // Users can only delete their own appointments
      allow delete: if isAuthenticated() && 
                      resource.data.customerId == request.auth.uid;
    }
    
    // Appointment counts collection
    match /appointmentCounts/{customerId} {
      // Users can read their own count
      allow read: if isAuthenticated() && 
                    (customerId == request.auth.uid);
      
      // Users can update their own count
      allow write: if isAuthenticated() && 
                     (customerId == request.auth.uid);
    }
  }
}
```

---

## 📋 Rule Testing

Firebase Console includes a Rules Playground where you can test your rules:

1. Go to: https://console.firebase.google.com/project/mobileias/firestore/rules
2. Click the **"Rules Playground"** tab
3. Test different operations to ensure your rules work correctly

---

## 🚨 Important Notes

### Test Mode Expiration
- Test mode rules allow anyone to read/write your database
- They expire after 30 days
- You'll get email warnings before expiration
- **Never use test mode in production!**

### Security Best Practices
1. ✅ Start with test mode during development
2. ✅ Implement authentication before production
3. ✅ Use the production rules above with auth
4. ✅ Test your rules thoroughly
5. ✅ Monitor security alerts in Firebase Console
6. ✅ Regularly review and audit your rules

### Common Errors

**Error: "Missing or insufficient permissions"**
- Solution: Update rules to test mode (see Quick Fix above)

**Error: "False for 'create' @ L5"**
- Solution: Your create rule is denying the operation
- Check if you're trying to write with authentication but not logged in

**Error: "Property is undefined on object"**
- Solution: Check your rule conditions for typos
- Make sure field names match your data structure

---

## 📚 Resources

- [Firestore Security Rules Guide](https://firebase.google.com/docs/firestore/security/get-started)
- [Rules Language Reference](https://firebase.google.com/docs/firestore/security/rules-structure)
- [Common Security Rules Patterns](https://firebase.google.com/docs/firestore/security/rules-conditions)
- [Rules Playground](https://firebase.google.com/docs/firestore/security/test-rules-emulator)

---

## 📊 Firestore Indexes (Optional)

**Good News:** The app now works without requiring composite indexes! We've optimized the queries to avoid this requirement.

However, if you want to create indexes for better performance with large datasets:

### Option 1: Auto-Create Index (Recommended)
Firebase will show you a link in the error message if an index is ever needed. Just click it and Firebase will create the index automatically.

### Option 2: Manual Index Creation
1. Go to: https://console.firebase.google.com/project/mobileias/firestore/indexes
2. Click **"Add Index"**
3. Configure:
   - **Collection ID**: `appointments`
   - **Fields**:
     - `customerId` - Ascending
     - `createdAt` - Descending
   - **Query scope**: Collection
4. Click **"Create"**

**Note:** Indexes take 1-5 minutes to build. You can use the app while they're building.

---

## ✅ Quick Checklist

- [ ] Go to Firebase Console → Firestore → Rules
- [ ] Copy the TEST MODE rules above
- [ ] Paste and click "Publish"
- [ ] Refresh your app
- [ ] Try creating an appointment
- [ ] Check Firebase Console to see the data

Once this is done, your app will work perfectly! 🎉
