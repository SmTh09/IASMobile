# Firebase Relational Database Structure

## Overview

This document describes the relational database structure implemented for the Parts Relocation system using Firebase Firestore.

## Collections

### 1. physicalLocations

Stores main physical locations where parts can be stored.

**Document Structure:**
```typescript
{
  id: string; // Document ID (e.g., "bmwParts", "mainWarehouse")
  name: string; // Display name (e.g., "BMW Parts", "Main Warehouse")
  address: string; // Physical address or location description
}
```

**Example:**
```json
{
  "id": "bmwParts",
  "name": "BMW Parts",
  "address": "Warehouse A - Section B"
}
```

### 2. shelves

Stores shelf references that belong to physical locations.

**Document Structure:**
```typescript
{
  id: string; // Document ID (e.g., "shelfA1", "shelfDEFB")
  label: string; // Shelf label (e.g., "A1", "DEFB")
  physicalLocationRef: string; // Reference to physicalLocations document ID
}
```

**Example:**
```json
{
  "id": "shelfDEFB",
  "label": "DEFB",
  "physicalLocationRef": "bmwParts"
}
```

### 3. parts

Stores individual part records with references to their physical location and shelf.

**Document Structure:**
```typescript
{
  id: string; // Auto-generated document ID
  partNumber: string; // Unique part number
  partName: string; // Part description/name
  currentAvailability: number; // Current quantity available
  
  // Reference fields (new structure)
  physicalLocationRef: string; // Reference to physicalLocations document ID
  shelfRef: string; // Reference to shelves document ID
  
  // Legacy fields (kept for backwards compatibility)
  physicalLocation: string; // Physical location name
  shelfAddress: string; // Shelf label
}
```

**Example:**
```json
{
  "id": "part001",
  "partNumber": "83210398511",
  "partName": "test package part",
  "currentAvailability": 56,
  "physicalLocationRef": "bmwParts",
  "shelfRef": "shelfDEFB",
  "physicalLocation": "BMW Parts",
  "shelfAddress": "DEFB"
}
```

### 4. relocations

Stores relocation records with references to parts, locations, and shelves.

**Document Structure:**
```typescript
{
  id: string; // Auto-generated document ID
  
  // Reference fields (new structure)
  partRef: string; // Reference to parts document ID
  fromLocationRef: string; // Reference to source physicalLocations document ID
  toLocationRef: string; // Reference to destination physicalLocations document ID
  fromShelfRef: string; // Reference to source shelves document ID
  toShelfRef: string; // Reference to destination shelves document ID
  
  // Metadata
  date: string; // ISO date string
  status: string; // "activated", "accepted", etc.
  createdBy: string; // User ID who created the relocation
  createdAt: Timestamp; // Firebase server timestamp
  qtyToRelocate: number; // Quantity being relocated
  
  // Legacy fields (kept for backwards compatibility)
  partId: string; // Same as partRef
  partNumber: string; // Denormalized for quick access
  partName: string; // Denormalized for quick access
  fromLocation: string; // Source location name
  toLocation: string; // Destination location name
  fromShelf: string; // Source shelf label
  toShelf: string; // Destination shelf label
  currentAvailability: number; // Part availability at time of relocation
}
```

**Example:**
```json
{
  "id": "reloc001",
  "partRef": "part001",
  "fromLocationRef": "bmwParts",
  "toLocationRef": "mainWarehouse",
  "fromShelfRef": "shelfDEFB",
  "toShelfRef": "shelfA1",
  "date": "2025-10-15T09:30:00Z",
  "status": "activated",
  "createdBy": "current_user",
  "qtyToRelocate": 5,
  "partNumber": "83210398511",
  "partName": "test package part",
  "fromLocation": "BMW Parts",
  "toLocation": "Main Warehouse",
  "fromShelf": "DEFB",
  "toShelf": "A1",
  "currentAvailability": 56
}
```

## Data Flow

### Creating a Relocation

1. User selects a part from the parts list
2. User specifies destination location and shelf
3. System creates a relocation document with:
   - References to the part, source/destination locations and shelves
   - Legacy fields for backwards compatibility
   - Status set to "activated"
   - Timestamp and user information

### Updating Part Location

When a relocation is completed/accepted:

1. Fetch the relocation document
2. Update the part document:
   - Set `physicalLocationRef` to `toLocationRef`
   - Set `shelfRef` to `toShelfRef`
   - Update legacy fields (`physicalLocation`, `shelfAddress`)

## Utility Functions

### Location & Shelf Operations

```typescript
// Fetch all physical locations
const locations = await fetchAllPhysicalLocations();

// Fetch all shelves with location data
const shelves = await fetchAllShelves(true);

// Fetch shelves for a specific location
const shelves = await fetchShelvesByLocation("bmwParts");
```

### Part Operations

```typescript
// Fetch a part with populated location and shelf data
const part = await fetchPartWithRelations("part001");
// Returns part with physicalLocationData and shelfData populated
```

### Relocation Operations

```typescript
// Fetch a relocation with all related data populated
const relocation = await fetchRelocationWithRelations("reloc001");
// Returns relocation with partData, fromLocationData, toLocationData, etc.

// Fetch all relocations with related data
const relocations = await fetchAllRelocationsWithRelations();
```

## Seeding Data

The database is automatically seeded on app initialization:

1. **Locations & Shelves**: Seeded via `seedLocationsAndShelves()`
   - Creates predefined physical locations (BMW Parts, Main Warehouse)
   - Creates predefined shelves linked to locations

2. **Parts**: Seeded via `seedParts()`
   - Creates sample parts with both reference and legacy fields
   - Skips if parts already exist

3. **Cleanup**: Automatic duplicate removal via `removeDuplicateParts()`
   - Runs before seeding to ensure clean data

## Migration Strategy

The implementation maintains **backwards compatibility** with the legacy structure:

- **Dual Fields**: Both reference fields (xxxRef) and legacy fields are maintained
- **Gradual Migration**: New relocations use references; old data remains accessible
- **Fallback Logic**: UI components check for relational data first, fall back to legacy fields

## Files

### Core Files

- `/utils/firebase/seedLocationsAndShelves.ts` - Seeds locations and shelves
- `/utils/firebase/seedParts.ts` - Seeds parts with references
- `/utils/firebase/relationalData.ts` - Utility functions for relational queries

### Updated Components

- `/components/NewPartsRelocation.tsx` - Creates relocations with references
- `/components/PartsRelocation.tsx` - Displays relocations with relational data
- `/App.tsx` - Initializes seeding on app load

## Security Considerations

Ensure Firestore security rules are updated to allow:

1. Read access to physicalLocations and shelves collections
2. Read/write access to parts and relocations for authenticated users
3. Proper validation of reference fields

See `/FIRESTORE_SECURITY_RULES.md` for detailed security rules.

## Future Enhancements

1. **User Selection**: Allow users to select destination location (not just shelf)
2. **Validation**: Add constraints to ensure referenced documents exist
3. **Cascading Updates**: Automatically update related documents when locations/shelves change
4. **History Tracking**: Maintain complete relocation history for each part
5. **Inventory Management**: Track real-time availability across all locations
