# Data Logic Refinement - Parts Relocation System

## 🎯 Overview

Complete refinement of the database structure and data validation logic for the Parts Relocation system, enforcing strict relationships and mandatory reference fields.

## ✅ Changes Made

### 1. **Database Structure - Mandatory References**

**Updated Interface:**
```typescript
interface Part {
  id: string;
  partNumber: string;
  partName?: string;
  description?: string;
  physicalLocation?: string;  // Legacy field
  shelfAddress?: string;       // Legacy field
  currentAvailability?: number;
  quantity?: number;
  physicalLocationRef: string;  // ✅ MANDATORY
  shelfRef: string;             // ✅ MANDATORY
}
```

**Key Changes:**
- `physicalLocationRef` is now **mandatory** (not optional)
- `shelfRef` is now **mandatory** (not optional)
- Every part MUST belong to exactly one physical location
- Every part MUST be assigned to exactly one shelf

### 2. **Part Validation Utilities**

**New File:** `/utils/firebase/partValidation.ts`

**Core Functions:**

#### `isPartRelocatable(part)`
```typescript
// Returns true only if:
// 1. Part has a physicalLocationRef
// 2. physicalLocationRef is NOT "mainWarehouse"
export function isPartRelocatable(part: PartForValidation): boolean {
  if (!part.physicalLocationRef) return false;
  if (part.physicalLocationRef === "mainWarehouse") return false;
  return true;
}
```

#### `getPartRelocationError(part)`
```typescript
// Returns error message or null
export function getPartRelocationError(part: PartForValidation): string | null {
  if (!part.physicalLocationRef) {
    return "This part does not have a valid physical location.";
  }
  if (part.physicalLocationRef === "mainWarehouse") {
    return "This part cannot be relocated from the Main Warehouse.";
  }
  return null;
}
```

#### `validatePartForRelocation(part)`
```typescript
// Throws error if part cannot be relocated
export function validatePartForRelocation(part: PartForValidation): void {
  const error = getPartRelocationError(part);
  if (error) throw new Error(error);
}
```

### 3. **SelectParts Component - Strict Filtering**

**Before:**
```typescript
// Checked both reference AND legacy fields
const isMainWarehouse = 
  part.physicalLocationRef === "mainWarehouse" ||
  part.physicalLocation?.toLowerCase().includes("main warehouse");
```

**After:**
```typescript
// Only checks physicalLocationRef (strict validation)
.filter((part) => {
  return isPartRelocatable(part);
});
```

**Filtering Logic:**
- ✅ **Only** checks `physicalLocationRef`
- ✅ No fallback to legacy fields
- ✅ Parts without `physicalLocationRef` are excluded
- ✅ Parts with `physicalLocationRef === "mainWarehouse"` are excluded

### 4. **NewPartsRelocation Component - Validation**

**Added Validation:**

```typescript
// State for validation error
const [partValidationError, setPartValidationError] = useState("");

// Validate part on selection
useEffect(() => {
  if (selectedPart) {
    const validationError = getPartRelocationError(selectedPart);
    setPartValidationError(validationError || "");
  } else {
    setPartValidationError("");
  }
}, [selectedPart]);

// Prevent submission if validation fails
const canSubmit = 
  selectedLocation && 
  selectedPart && 
  qtyToRelocate && 
  selectedShelfId && 
  !quantityError && 
  !partValidationError &&  // ✅ NEW
  !isSubmitting;
```

**Error Display:**
```tsx
{partValidationError && (
  <div className="bg-[#fff1f1] border-l-4 border-[#da1e28] p-[16px] w-full">
    <p className="font-['IBM_Plex_Sans:Regular',_sans-serif] text-[#da1e28] text-[14px]">
      {partValidationError}
    </p>
  </div>
)}
```

### 5. **Database Collections Structure**

#### **physicalLocations Collection**
```typescript
{
  id: "bmwParts" | "mainWarehouse" | ...,
  name: "BMW Parts" | "Main Warehouse" | ...,
  // other metadata
}
```

#### **shelves Collection**
```typescript
{
  id: "shelfB1" | "shelfB2" | ...,
  label: "B1" | "B2" | ...,
  physicalLocationRef: "bmwParts",  // Reference to physicalLocations
  // other metadata
}
```

#### **parts Collection** (Updated)
```typescript
{
  id: "...",
  partNumber: "83210398511",
  partName: "test package part",
  physicalLocationRef: "bmwParts",     // ✅ MANDATORY reference
  shelfRef: "shelfDEFB",               // ✅ MANDATORY reference
  physicalLocation: "BMW Parts",       // Legacy field
  shelfAddress: "DEFB",                // Legacy field
  currentAvailability: 56
}
```

#### **relocations Collection**
```typescript
{
  id: "...",
  partRef: "...",                      // Reference to parts
  fromLocationRef: "bmwParts",         // Reference to physicalLocations
  toLocationRef: "mainWarehouse",      // Reference to physicalLocations
  fromShelfRef: "shelfB1",             // Reference to shelves
  toShelfRef: "shelfA1",               // Reference to shelves
  // Legacy fields for backwards compatibility
  partNumber: "83210398511",
  fromLocation: "BMW Parts",
  toLocation: "Main Warehouse",
  // metadata
  qtyToRelocate: 5,
  status: "activated",
  createdAt: serverTimestamp()
}
```

## 📋 Validation Rules

### Rule 1: Part Must Have physicalLocationRef
```
❌ Part without physicalLocationRef
   → Cannot appear in Select Parts list
   → Error: "This part does not have a valid physical location."
```

### Rule 2: Part Cannot Be in Main Warehouse
```
❌ Part with physicalLocationRef === "mainWarehouse"
   → Cannot appear in Select Parts list
   → Error: "This part cannot be relocated from the Main Warehouse."
```

### Rule 3: Only Reference Field Matters
```
✅ Only physicalLocationRef is checked
❌ Legacy physicalLocation field is ignored for validation
```

### Rule 4: Visual AND Logical Validation
```
Visual:   Parts don't appear in list
Logical:  Even if manually added, validation prevents relocation
```

## 🔍 Examples

### ✅ Valid Part (Can Be Relocated)

```json
{
  "id": "part123",
  "partNumber": "83210398511",
  "partName": "test package part",
  "physicalLocationRef": "bmwParts",
  "shelfRef": "shelfDEFB",
  "currentAvailability": 56
}
```
**Result:**
- ✅ Appears in Select Parts list
- ✅ Can be selected
- ✅ Can be relocated

### ❌ Invalid Part (Main Warehouse)

```json
{
  "id": "part456",
  "partNumber": "ABC123",
  "partName": "Completed Part",
  "physicalLocationRef": "mainWarehouse",
  "shelfRef": "shelfA1",
  "currentAvailability": 30
}
```
**Result:**
- ❌ Does NOT appear in Select Parts list
- ❌ Cannot be selected
- ❌ Validation error if manually added: "This part cannot be relocated from the Main Warehouse."

### ❌ Invalid Part (No Location Reference)

```json
{
  "id": "part789",
  "partNumber": "XYZ789",
  "partName": "Orphaned Part",
  "physicalLocationRef": "",
  "shelfRef": "",
  "currentAvailability": 10
}
```
**Result:**
- ❌ Does NOT appear in Select Parts list
- ❌ Cannot be selected
- ❌ Validation error if manually added: "This part does not have a valid physical location."

## 🎨 Design Consistency

### Error Message Styling

**Validation Error Banner:**
```tsx
<div className="bg-[#fff1f1] border-l-4 border-[#da1e28] p-[16px] w-full">
  <p className="font-['IBM_Plex_Sans:Regular',_sans-serif] text-[#da1e28] text-[14px]">
    {partValidationError}
  </p>
</div>
```

**Styling Details:**
- Background: `#fff1f1` (light red)
- Border Left: `4px solid #da1e28` (error red)
- Font: IBM Plex Sans Regular, 14px
- Color: `#da1e28` (error red)
- Padding: 16px
- Matches existing error design system

### Field Validation Error

**Quantity Error (existing):**
```tsx
<p className="font-['IBM_Plex_Sans:Light',_sans-serif] text-[#da1e28] text-[12px]">
  {quantityError}
</p>
```

**Consistency:**
- Same color: `#da1e28`
- Same font family: IBM Plex Sans
- Different weight: Light vs Regular
- Different size: 12px vs 14px (banner is more prominent)

## 🏗️ Data Flow

### Complete Validation Flow

```
1. User Opens Select Parts
   ↓
2. Load all parts from Firebase
   ↓
3. Filter using isPartRelocatable()
   - ✅ Has physicalLocationRef?
   - ✅ Not mainWarehouse?
   ↓
4. Display filtered list
   ↓
5. User Selects Part
   ↓
6. Navigate to New Parts Relocation
   ↓
7. Validate part with getPartRelocationError()
   - Show error banner if invalid
   - Disable submit button
   ↓
8. If Valid: User enters quantity and shelf
   ↓
9. Submit: Final validation before save
   ↓
10. Success: Create relocation and update part
```

### Validation Checkpoints

| Checkpoint | Location | Function | Action |
|------------|----------|----------|--------|
| **Load Time** | SelectParts | `isPartRelocatable()` | Filter list |
| **Selection Time** | NewPartsRelocation | `getPartRelocationError()` | Show error banner |
| **Submit Time** | NewPartsRelocation | `getPartRelocationError()` | Prevent submission |

## 🔧 Technical Implementation

### File Structure

```
utils/firebase/
├── partValidation.ts          ✅ NEW - Validation utilities
├── seedParts.ts               ✅ UPDATED - Mandatory refs
├── relationalData.ts          (existing)
└── firestore.ts               (existing)

components/
├── SelectParts.tsx            ✅ UPDATED - Strict filtering
├── NewPartsRelocation.tsx     ✅ UPDATED - Validation display
└── PartsRelocation.tsx        (existing)
```

### Import Changes

**SelectParts.tsx:**
```typescript
import { isPartRelocatable } from "../utils/firebase/partValidation";
```

**NewPartsRelocation.tsx:**
```typescript
import { 
  getPartRelocationError, 
  isPartRelocatable 
} from "../utils/firebase/partValidation";
```

### Interface Updates

**Before (Optional References):**
```typescript
interface Part {
  physicalLocationRef?: string;  // Optional
  shelfRef?: string;             // Optional
}
```

**After (Mandatory References):**
```typescript
interface Part {
  physicalLocationRef: string;   // Required
  shelfRef: string;              // Required
}
```

## 📊 Validation Matrix

| Scenario | physicalLocationRef | Result | Error Message |
|----------|---------------------|--------|---------------|
| Valid Part | `"bmwParts"` | ✅ Can relocate | None |
| Main Warehouse | `"mainWarehouse"` | ❌ Cannot relocate | "This part cannot be relocated from the Main Warehouse." |
| No Reference | `""` or `undefined` | ❌ Cannot relocate | "This part does not have a valid physical location." |
| Other Location | `"customLocation"` | ✅ Can relocate | None |

## 🚀 Benefits

### For Data Integrity

✅ **Mandatory Relationships**
- Every part MUST have a location
- No orphaned parts
- Clear data structure

✅ **Strict Validation**
- Only reference fields matter
- No fallback to legacy fields
- Consistent validation rules

✅ **Prevents Invalid Operations**
- Main Warehouse parts protected
- Invalid parts filtered out
- Double validation (visual + logical)

### For Users

✅ **Clear Feedback**
- Error banner shows why part is invalid
- Consistent error styling
- Prevents confusion

✅ **Guided Workflow**
- Only see valid parts
- Submit button disabled if invalid
- No wasted effort

✅ **Professional UX**
- Validation errors match design system
- Clear, specific error messages
- Helpful guidance

### For Developers

✅ **Reusable Utilities**
- `isPartRelocatable()` for filtering
- `getPartRelocationError()` for messages
- `validatePartForRelocation()` for exceptions

✅ **Type Safety**
- Mandatory references in TypeScript
- Compile-time checks
- Clear interfaces

✅ **Maintainable**
- Single source of truth for validation
- Easy to update rules
- Well-documented

## 🧪 Testing Scenarios

### Test 1: Valid Part Selection
```
Given: Part with physicalLocationRef = "bmwParts"
When: User opens Select Parts
Then: Part appears in list
And: User can select it
And: No validation error shown
And: Can submit relocation
```

### Test 2: Main Warehouse Part
```
Given: Part with physicalLocationRef = "mainWarehouse"
When: User opens Select Parts
Then: Part does NOT appear in list
And: User cannot select it
```

### Test 3: Manual Main Warehouse Part (Edge Case)
```
Given: Main Warehouse part somehow passed to NewPartsRelocation
When: Component loads
Then: Validation error banner displays
And: Error: "This part cannot be relocated from the Main Warehouse."
And: Submit button is disabled
```

### Test 4: Part Without Location
```
Given: Part with empty or missing physicalLocationRef
When: User opens Select Parts
Then: Part does NOT appear in list
And: User cannot select it
```

### Test 5: Validation Error Display
```
Given: Invalid part in NewPartsRelocation
When: Component renders
Then: Red banner displays at top
And: Banner has error message
And: Banner uses error design system
And: Submit button is disabled
```

## 📝 Migration Notes

### Existing Data

**All seed parts already have references:**
```typescript
{
  physicalLocationRef: "bmwParts",
  shelfRef: "shelfDEFB"
}
```

**Legacy Fields Maintained:**
```typescript
{
  physicalLocation: "BMW Parts",  // Still present
  shelfAddress: "DEFB"            // Still present
}
```

**Backwards Compatibility:**
- Legacy fields preserved
- Old relocations still readable
- New relocations use references

### Required Actions

For any custom parts added outside seed data:

1. ✅ Ensure `physicalLocationRef` is set
2. ✅ Ensure `shelfRef` is set
3. ✅ Reference must point to valid physicalLocation
4. ✅ Shelf must belong to that location

## 📚 Related Files

### Created
- `/utils/firebase/partValidation.ts` - Validation utilities

### Updated
- `/utils/firebase/seedParts.ts` - Mandatory interfaces
- `/components/SelectParts.tsx` - Strict filtering
- `/components/NewPartsRelocation.tsx` - Validation display

### Documentation
- `/DATA_LOGIC_REFINEMENT.md` - This file
- `/PARTS_SELECTION_FILTERING.md` - Selection logic
- `/NEW_PARTS_RELOCATION_UPDATE.md` - Relocation features
- `/FIREBASE_RELATIONAL_STRUCTURE.md` - Database structure

## ✅ Summary

### Database Structure
✅ Every part MUST have `physicalLocationRef` (mandatory)  
✅ Every part MUST have `shelfRef` (mandatory)  
✅ References point to actual documents  
✅ Legacy fields preserved for compatibility  

### Validation
✅ Strict validation using only reference fields  
✅ Main Warehouse parts cannot be relocated  
✅ Parts without location cannot be selected  
✅ Visual AND logical validation  

### User Experience
✅ Clear error messages  
✅ Consistent design system  
✅ Error banners for invalid parts  
✅ Submit disabled when invalid  

### Code Quality
✅ Reusable validation utilities  
✅ Type-safe interfaces  
✅ Single source of truth  
✅ Well-documented  

The Parts Relocation system now enforces strict data relationships with comprehensive validation at every level! 🎉
