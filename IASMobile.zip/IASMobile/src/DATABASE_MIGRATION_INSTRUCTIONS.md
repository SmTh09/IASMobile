# Database Migration Instructions

## Overview

This guide explains how to migrate your Firebase database to the new relational structure where:
- Parts can exist in multiple physical locations
- Shelves belong to one physical location
- Relocations respect physical location boundaries

## Current State Check

When you load the app, check the browser console. You should see:
```
📊 Current Database State:
   Parts: X
   Shelves: Y
   Physical Locations: Z
   Relocations: W
   Using New Structure: ❌ No
   ⚠️  Old structure detected - migration needed
```

## Migration Methods

### Method 1: Using the Migration Button (Recommended)

1. **Look for the red button** in the bottom-right corner of the screen that says "🔄 Migrate Database"

2. **Click the button** - A confirmation dialog will appear:
   ```
   ⚠️ This will DELETE all existing data and create a new database structure. 
   Are you sure?
   ```

3. **Confirm** - Click OK to proceed with the migration

4. **Wait** - You'll see a loading state "Migrating..." while the process runs

5. **Success** - When complete, you'll see a success toast with details:
   ```
   ✅ Database migration completed successfully!
   Locations: 2, Shelves: 15, Parts: 4
   ```

6. **Refresh the page** to load the new structure

### Method 2: Using Browser Console

If the button doesn't appear or you prefer manual control:

1. Open browser console (F12 or Right-click → Inspect → Console)

2. Run the migration function:
   ```javascript
   // Import the migration function
   const { migrateToNewStructure } = await import('./utils/firebase/migrateToNewStructure.ts');
   
   // Run migration
   const result = await migrateToNewStructure();
   console.log(result);
   ```

3. Check the result in the console

4. Refresh the page

## What the Migration Does

### Step 1: Clear Old Data
- Deletes all existing parts (old structure)
- Deletes all existing shelves (old structure)
- Deletes all existing physical locations (old structure)
- **Note:** Relocations are preserved (optional)

### Step 2: Seed Physical Locations
Creates 2 physical locations:
```json
{
  "bmwParts": {
    "name": "BMW Parts",
    "address": "Warehouse A - Section B",
    "createdDate": "2020-10-01T13:48:11",
    "createdBy": "System Administrator"
  },
  "mainWarehouse": {
    "name": "Main Warehouse",
    "address": "Central Storage - Level 1",
    "createdDate": "2020-10-01T13:48:11",
    "createdBy": "System Administrator"
  }
}
```

### Step 3: Seed Shelves
Creates 15 shelves:

**BMW Parts (14 shelves):**
- A1, A2, B1, B2, B3, B4, B5, B6, B7, C1, C2, D1, D2, DEFB

**Main Warehouse (1 shelf):**
- BK1

Each shelf document:
```json
{
  "code": "B1",
  "description": "Shelf B1",
  "isDefault": false,
  "createdDate": "2020-10-01T13:48:11",
  "createdBy": "System Administrator",
  "physicalLocationID": "bmwParts"
}
```

### Step 4: Seed Parts
Creates 4 parts with the new structure:

**Part 1: 83210398511** (test package part)
- Location: BMW Parts only
- Shelf: DEFB
- Quantity: 56

**Part 2: 11227508000** (New Test Part)
- Location: BMW Parts only
- Shelf: DEFB
- Quantity: 17

**Part 3: 11427512300** (SET OIL-FILTER ELEMENT)
- Location: BMW Parts only
- Shelf: B3
- Quantity: 27

**Part 4: WH340** (ALL TERRAIN WHEEL) - Multi-location example
- Location 1: BMW Parts
  - Shelves: B1, B2, B3, B4, B6, B7
  - Quantities: 30, 35, 25, 20, 34, 15
- Location 2: Main Warehouse
  - Shelf: BK1
  - Quantity: 50

Example part document:
```json
{
  "partNumber": "WH340",
  "description": "ALL TERRAIN WHEEL",
  "physicalLocations": [
    {
      "id": "bmwParts",
      "shelves": ["shelfB1", "shelfB2", "shelfB3", "shelfB4", "shelfB6", "shelfB7"]
    },
    {
      "id": "mainWarehouse",
      "shelves": ["shelfBK1"]
    }
  ],
  "quantities": [
    { "shelfID": "shelfB1", "quantity": 30 },
    { "shelfID": "shelfB2", "quantity": 35 },
    { "shelfID": "shelfB3", "quantity": 25 },
    { "shelfID": "shelfB4", "quantity": 20 },
    { "shelfID": "shelfB6", "quantity": 34 },
    { "shelfID": "shelfB7", "quantity": 15 },
    { "shelfID": "shelfBK1", "quantity": 50 }
  ]
}
```

## Verification

After migration, check the console again:
```
📊 Current Database State:
   Parts: 4
   Shelves: 15
   Physical Locations: 2
   Relocations: 0 (or preserved count)
   Using New Structure: ✅ Yes
```

## Testing the New Structure

### Test 1: View Parts
1. Navigate to Parts Relocation
2. You should see parts listed with their locations and shelves
3. Part WH340 should appear multiple times (once per shelf)

### Test 2: Create a Relocation
1. Click "+ New" in Parts Relocation
2. Click "Add Part"
3. Select a part (e.g., WH340 from shelf B1)
4. The "New Shelf" dropdown should only show shelves B2, B3, B4, B6, B7 (same location, excluding B1)
5. Enter a quantity (max 30 for B1)
6. Confirm and Submit
7. Verify the relocation appears in the list

### Test 3: Multi-Location Part
1. Add WH340 from shelf BK1 (Main Warehouse)
2. The "New Shelf" dropdown should be empty (BK1 is the only shelf in Main Warehouse)
3. This demonstrates location boundary enforcement

## Troubleshooting

### Migration Button Doesn't Appear
- Check browser console for errors
- Refresh the page
- Use Method 2 (console) instead

### Migration Fails
- Check Firebase permissions in Firebase Console
- Ensure you have write access to Firestore
- Check browser console for specific error messages

### Data Doesn't Show After Migration
- Refresh the page
- Clear browser cache
- Check Firebase Console to verify data was created

### Old Structure Still Shows
- The migration may have failed silently
- Run `checkDatabaseState()` in console to verify
- Try running the migration again

## Rollback

If you need to revert:

1. The old data is deleted, so you'll need to restore from a backup
2. If you have a Firestore backup, restore it in Firebase Console
3. Alternatively, re-run the old seeding scripts if available

## Notes

- **This migration is destructive** - old data will be deleted
- **Relocations are preserved** by default (commented out in cleanup)
- **No backup is created automatically** - back up manually if needed
- **Run during off-hours** if in production
- **Test in development first** before running in production

## Support

If you encounter issues:
1. Check the browser console for error messages
2. Check the Firebase Console Firestore tab to see actual data
3. Verify Firebase security rules allow reads/writes
4. Review the migration code in `/utils/firebase/migrateToNewStructure.ts`
