# Parts Database Seeding

## Overview

The application automatically seeds the Firebase `parts` collection with sample parts data when the app first loads.

## Parts Data

The following parts are included in the seed data:

1. **Part No: 83210398511**
   - Name: test package part
   - Location: BMW Parts, Shelf DEFB
   - Availability: 56

2. **Part No: 11227508000**
   - Name: New Test Part
   - Location: BMW Parts, Shelf DEFB
   - Availability: 17

3. **Part No: 11427512300**
   - Name: SET OIL-FILTER ELEMENT
   - Location: BMW Parts, Shelf B3
   - Availability: 27

4. **Part No: WH340** (Multiple shelf locations)
   - Name: ALL TERRAIN WHEEL
   - Location: BMW Parts
   - Multiple shelf addresses: B1, B2, B6
   - Varying availability: 30-35 units

## Automatic Seeding & Duplicate Removal

**On Every App Load:**
1. The app automatically checks for and removes duplicate parts
2. This runs in the background every time you start/refresh the app
3. Console logs show: "Checking for duplicate parts..." and "Successfully removed X duplicate parts"

**Seeding:**
- Parts are only seeded when the `parts` collection in Firebase is empty
- Seeding happens after duplicate removal
- If parts exist, seeding is skipped

**Duplicate Detection**: Two parts are considered duplicates if ALL of the following fields match:
- Part Number
- Part Name
- Physical Location
- Shelf Address
- Current Availability

The first occurrence is kept, and all subsequent duplicates are automatically deleted.

## Manual Management

You can manually manage the parts database using the utility functions:

```typescript
import { seedParts, clearParts, removeDuplicateParts } from "./utils/firebase/seedParts";

// Seed the database (also removes duplicates first)
await seedParts();

// Remove duplicate parts only
await removeDuplicateParts();

// Clear all parts
await clearParts();
```

### Using the Management UI

The optional `SeedPartsButton` component provides a UI for manual management:

```typescript
import SeedPartsButton from "./components/SeedPartsButton";

// Use in your app
<SeedPartsButton />
```

Features:
- **Seed Parts**: Add initial parts data to the database
- **Remove Duplicates**: Scan and remove any duplicate parts
- **Clear All Parts**: Delete all parts from the database (requires confirmation)

## Database Structure

Each part document in the `parts` collection has the following fields:

```typescript
{
  partNumber: string;           // e.g., "83210398511"
  partName: string;             // e.g., "test package part"
  physicalLocation: string;     // e.g., "BMW Parts"
  shelfAddress: string;         // e.g., "DEFB"
  currentAvailability: number;  // e.g., 56
}
```

## Files

- `/utils/firebase/seedParts.ts` - Seeding utility functions
- `/components/SeedPartsButton.tsx` - Manual seed management UI (optional)
