# New Database Structure - Relational Model

## Overview

The database has been restructured to implement a proper relational model where:
- **Physical Locations** are separate entities
- **Shelves** belong to Physical Locations
- **Parts** can exist in multiple Physical Locations with different shelves
- **Relocations** respect Physical Location boundaries

## Collections

### 1. Physical Locations Collection

**Collection Name:** `physicalLocations`

**Document Structure:**
```typescript
{
  id: "bmwParts" | "mainWarehouse",  // Document ID
  name: string,                      // "BMW Parts" | "Main Warehouse"
  address: string,                   // Physical address
  createdDate: string,               // ISO format
  createdBy: string                  // "System Administrator"
}
```

**Example:**
```json
{
  "id": "bmwParts",
  "name": "BMW Parts",
  "address": "Warehouse A - Section B",
  "createdDate": "2020-10-01T13:48:11",
  "createdBy": "System Administrator"
}
```

### 2. Shelves Collection

**Collection Name:** `shelves`

**Document Structure:**
```typescript
{
  id: string,                        // Document ID: "shelfA1", "shelfB1", etc.
  code: string,                      // "A1", "B1", "BK1", etc.
  description: string,               // "Shelf A1"
  isDefault: boolean,                // false
  createdDate: string,               // ISO format
  createdBy: string,                 // "System Administrator"
  physicalLocationID: string         // Reference to Physical Location
}
```

**Example:**
```json
{
  "id": "shelfB1",
  "code": "B1",
  "description": "Shelf B1",
  "isDefault": false,
  "createdDate": "2020-10-01T13:48:11",
  "createdBy": "System Administrator",
  "physicalLocationID": "bmwParts"
}
```

**Shelves per Location:**

**BMW Parts Shelves:**
- A1, A2, B1, B2, B3, B4, B5, B6, B7, C1, C2, D1, D2, DEFB

**Main Warehouse Shelves:**
- BK1

### 3. Parts Collection

**Collection Name:** `parts`

**Document Structure:**
```typescript
{
  id: string,                        // Document ID (sanitized part number)
  partNumber: string,                // "WH340", "83210398511", etc.
  description: string,               // Part description
  physicalLocations: Array<{         // Multiple locations
    id: string,                      // Physical Location ID
    shelves: string[]                // Array of shelf IDs in this location
  }>,
  quantities: Array<{                // Quantities per shelf
    shelfID: string,                 // Shelf ID
    quantity: number                 // Available quantity
  }>
}
```

**Example - Part in Multiple Locations:**
```json
{
  "id": "WH340",
  "partNumber": "WH340",
  "description": "ALL TERRAIN WHEEL",
  "physicalLocations": [
    {
      "id": "bmwParts",
      "shelves": ["shelfB1", "shelfB2", "shelfB3", "shelfB4", "shelfB6", "shelfB7"]
    },
    {
      "id": "mainWarehouse",
      "shelves": ["shelfBK1"]
    }
  ],
  "quantities": [
    { "shelfID": "shelfB1", "quantity": 30 },
    { "shelfID": "shelfB2", "quantity": 35 },
    { "shelfID": "shelfB3", "quantity": 25 },
    { "shelfID": "shelfB4", "quantity": 20 },
    { "shelfID": "shelfB6", "quantity": 34 },
    { "shelfID": "shelfB7", "quantity": 15 },
    { "shelfID": "shelfBK1", "quantity": 50 }
  ]
}
```

### 4. Relocations Collection

**Collection Name:** `relocations`

**Document Structure:**
```typescript
{
  id: string,                        // Auto-generated document ID
  partID: string,                    // Reference to Part document
  partNumber: string,                // Part number for quick reference
  description: string,               // Part description
  physicalLocationID: string,        // The location where relocation occurs
  fromShelfID: string,               // Source shelf ID
  toShelfID: string,                 // Destination shelf ID
  quantity: number,                  // Quantity relocated
  date: string,                      // Date in YYYY-MM-DD format
  status: string,                    // "activated"
  timestamp: Timestamp,              // Firestore timestamp
  createdBy: string                  // "System Administrator"
}
```

**Example:**
```json
{
  "id": "rel_12345",
  "partID": "WH340",
  "partNumber": "WH340",
  "description": "ALL TERRAIN WHEEL",
  "physicalLocationID": "bmwParts",
  "fromShelfID": "shelfB1",
  "toShelfID": "shelfB2",
  "quantity": 5,
  "date": "2025-01-15",
  "status": "activated",
  "timestamp": "2025-01-15T10:30:00Z",
  "createdBy": "System Administrator"
}
```

## Key Relationships

```
Physical Location (bmwParts)
  ├─ Shelf (shelfA1)
  ├─ Shelf (shelfB1)
  └─ Shelf (shelfB2)
  
Part (WH340)
  ├─ Physical Location (bmwParts)
  │   └─ Shelves: [shelfB1, shelfB2, shelfB3]
  └─ Physical Location (mainWarehouse)
      └─ Shelves: [shelfBK1]
  
Relocation
  ├─ Part (WH340)
  ├─ Physical Location (bmwParts)
  ├─ From Shelf (shelfB1)
  └─ To Shelf (shelfB2)
```

## Relocation Logic

### Rules

1. **Location Boundary**: Parts can only be relocated between shelves in the same Physical Location
2. **Shelf Validation**: The "New Shelf" dropdown shows ALL shelves that:
   - Belong to the same Physical Location as the source shelf
   - Are not the current source shelf
   - Note: Part does NOT need to exist on the destination shelf beforehand

3. **Quantity Validation**:
   - Quantity must be > 0
   - Quantity must be ≤ available quantity on source shelf
   - Available quantity is retrieved from `part.quantities` array

4. **Auto-Update**: When relocating to a new shelf:
   - The destination shelf is automatically added to the part's `physicalLocations.shelves` array
   - A new quantity entry is created in the part's `quantities` array

### Relocation Flow

1. **User selects a part** from a specific shelf
2. **System determines Physical Location** from the shelf's `physicalLocationID`
3. **System fetches available shelves**:
   ```typescript
   // Fetch ALL shelves in the same physical location (excluding current shelf)
   const availableShelves = await fetchShelvesByLocation(physicalLocationID);
   const filteredShelves = availableShelves.filter(shelf => shelf.id !== currentShelfID);
   ```
4. **User selects destination shelf and quantity**
5. **System validates**:
   - Destination shelf is in the same location
   - Quantity is valid
6. **System updates atomically**:
   - Create relocation record
   - Update part's `quantities` array (deduct from source, add to destination)
   - Update part's `physicalLocations` to include destination shelf if new

### Example Relocation Process

#### Example 1: Relocate to Existing Shelf

**Initial State:**
```json
Part WH340 in BMW Parts:
- shelfB1: 30 units
- shelfB2: 35 units
physicalLocations: [{ id: "bmwParts", shelves: ["shelfB1", "shelfB2"] }]
```

**User Action:**
- Relocate 5 units from shelfB1 to shelfB2

**Available Shelves Dropdown:**
- Shows: A1, A2, B2, B3, B4, B5, B6, B7, C1, C2, D1, D2, DEFB (all BMW Parts shelves except B1)

**System Actions:**
1. Validate: shelfB1 has 30 units (≥ 5) ✓
2. Validate: shelfB2 is in BMW Parts ✓
3. Create relocation record
4. Update quantities:
   - shelfB1: 30 - 5 = 25 units
   - shelfB2: 35 + 5 = 40 units

**Final State:**
```json
Part WH340 in BMW Parts:
- shelfB1: 25 units
- shelfB2: 40 units
physicalLocations: [{ id: "bmwParts", shelves: ["shelfB1", "shelfB2"] }] (unchanged)
```

#### Example 2: Relocate to New Shelf

**Initial State:**
```json
Part 11427512300 in BMW Parts:
- shelfB3: 27 units
physicalLocations: [{ id: "bmwParts", shelves: ["shelfB3"] }]
```

**User Action:**
- Relocate 10 units from shelfB3 to shelfA1 (new shelf for this part)

**Available Shelves Dropdown:**
- Shows: A1, A2, B1, B2, B4, B5, B6, B7, C1, C2, D1, D2, DEFB (all BMW Parts shelves except B3)

**System Actions:**
1. Validate: shelfB3 has 27 units (≥ 10) ✓
2. Validate: shelfA1 is in BMW Parts ✓
3. Create relocation record
4. Update quantities:
   - shelfB3: 27 - 10 = 17 units
   - shelfA1: 0 + 10 = 10 units (NEW)
5. Update physicalLocations:
   - Add shelfA1 to shelves array

**Final State:**
```json
Part 11427512300 in BMW Parts:
- shelfB3: 17 units
- shelfA1: 10 units (NEW)
physicalLocations: [{ id: "bmwParts", shelves: ["shelfB3", "shelfA1"] }] (updated)
```

## API Functions

### relationalData.ts

- `fetchPhysicalLocation(locationId)` - Get location by ID
- `fetchShelf(shelfId)` - Get shelf by ID
- `fetchAllPhysicalLocations()` - Get all locations
- `fetchAllShelves()` - Get all shelves
- `fetchShelvesByLocation(locationId)` - Get shelves for a location
- `fetchShelvesForPartInLocation(partNumber, locationID, currentShelfID)` - Get available destination shelves
- `fetchAllPartShelfInstances()` - Get all part-shelf combinations
- `fetchPartShelfInstancesByLocation(locationId)` - Get part-shelf instances for a location
- `fetchPart(partId)` - Get part by ID
- `fetchPartByPartNumber(partNumber)` - Get part by part number
- `getPartQuantityOnShelf(part, shelfID)` - Get quantity on specific shelf

### relocations.ts

- `createRelocation(params)` - Create a new relocation
  - Validates quantity and location boundaries
  - Updates part quantities atomically
  - Creates relocation record
- `getRelocationsByPart(partId)` - Get all relocations for a part
- `getAllRelocations()` - Get all relocations

### Seeding Functions

- `seedPhysicalLocations()` - Seed BMW Parts and Main Warehouse
- `seedShelves()` - Seed all 15 shelves (14 BMW + 1 Main Warehouse)
- `seedParts()` - Seed parts with multi-location support
- `seedLocationsAndShelves()` - Seed both locations and shelves

## Migration from Old Structure

The old structure had:
- Parts with a single `physicalLocationRef` and `shelfStocks` array
- Legacy fields for backwards compatibility

The new structure:
- Parts with `physicalLocations` array (multiple locations)
- Parts with `quantities` array (per-shelf quantities)
- Cleaner separation of concerns

**To migrate existing data:**
1. Clear old parts: `clearParts()`
2. Re-seed with new structure: `seedLocationsAndShelves()` then `seedParts()`

## Benefits

1. **Normalized Data**: Each entity is stored once
2. **Multi-Location Support**: Parts can exist in multiple physical locations
3. **Location Boundaries**: Relocations respect physical location constraints
4. **Scalability**: Easy to add new locations and shelves
5. **Data Integrity**: Atomic operations ensure consistency
6. **Clear Relationships**: Easy to understand and maintain

## Usage Examples

### Get all parts in BMW Parts location
```typescript
const instances = await fetchPartShelfInstancesByLocation('bmwParts');
```

### Get available shelves for relocation
```typescript
const availableShelves = await fetchShelvesForPartInLocation(
  'WH340',              // Part number
  'bmwParts',           // Physical location
  'shelfB1'             // Current shelf (excluded from results)
);
```

### Create a relocation
```typescript
const result = await createRelocation({
  partId: 'WH340',
  partNumber: 'WH340',
  description: 'ALL TERRAIN WHEEL',
  physicalLocationID: 'bmwParts',
  fromShelfID: 'shelfB1',
  toShelfID: 'shelfB2',
  quantity: 5
});
```

### Get quantity on a specific shelf
```typescript
const part = await fetchPartByPartNumber('WH340');
const quantity = getPartQuantityOnShelf(part, 'shelfB1');
// Returns: 30
```
