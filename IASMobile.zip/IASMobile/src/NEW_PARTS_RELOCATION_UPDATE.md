# New Parts Relocation Page - Database & UI Updates

## 🎯 Overview

Successfully updated the "New Parts Relocation" page with dynamic dropdowns, real-time validation, and proper database relationships.

## ✅ Changes Implemented

### 1. **Physical Location Dropdown**

**What Changed:**
- Dropdown now dynamically fetches locations from the `physicalLocations` collection in Firebase
- Displays location names (e.g., "BMW Parts", "Main Warehouse")
- Updates available shelves when location changes

**Implementation:**
```typescript
// Fetches locations on mount
const [physicalLocations, setPhysicalLocations] = useState<PhysicalLocation[]>([]);
const [selectedLocation, setSelectedLocation] = useState<PhysicalLocation | null>(null);

useEffect(() => {
  const loadLocations = async () => {
    const locations = await fetchAllPhysicalLocations();
    setPhysicalLocations(locations);
    if (locations.length > 0 && !selectedLocation) {
      setSelectedLocation(locations[0]);
    }
  };
  loadLocations();
}, []);
```

**UI:**
- Dropdown appears below the location field when clicked
- Shows all available physical locations
- Closes when selecting a location or clicking outside

### 2. **New Shelf Dropdown**

**What Changed:**
- Dynamically fetches shelves from the `shelves` collection
- Filters shelves based on selected physical location
- Excludes the part's current shelf from the list
- Only shows shelves that are different from the current one

**Implementation:**
```typescript
// Fetches shelves based on location and filters out current shelf
useEffect(() => {
  const loadShelves = async () => {
    if (selectedPart?.physicalLocationRef && selectedLocation) {
      const shelves = await fetchShelvesByLocation(selectedLocation.id);
      const filtered = shelves.filter(shelf => shelf.id !== selectedPart.shelfRef);
      setAvailableShelves(filtered);
    }
  };
  loadShelves();
}, [selectedPart, selectedLocation]);
```

**UI:**
- Dropdown shows shelf labels (e.g., "B1", "B2", "B3")
- If current shelf is B1, only shows B2, B3, etc.
- Shows "No available shelves" if no other shelves exist

### 3. **Quantity to Relocate Validation**

**What Changed:**
- Real-time validation as user types
- Validates against current available quantity
- Shows inline error message if quantity exceeds stock
- Prevents submission if validation fails

**Implementation:**
```typescript
const handleQtyChange = (value: string) => {
  setQtyToRelocate(value);
  
  // Validate quantity
  const qty = parseInt(value);
  const available = selectedPart?.currentAvailability || 0;
  
  if (value && (isNaN(qty) || qty <= 0)) {
    setQuantityError("Please enter a valid quantity.");
  } else if (qty > available) {
    setQuantityError("Quantity exceeds available stock. Please enter a lower amount.");
  } else {
    setQuantityError("");
  }
};
```

**Error Message Styling:**
```typescript
{quantityError && (
  <p className="font-['IBM_Plex_Sans:Light',_sans-serif] leading-[normal] not-italic text-[#da1e28] text-[12px]">
    {quantityError}
  </p>
)}
```

**Validation Rules:**
- ✅ Must be a valid number
- ✅ Must be greater than 0
- ✅ Must not exceed `currentAvailability`
- ✅ Error displays immediately as user types
- ✅ Submit button disabled if validation fails

### 4. **Database Relationships**

**What Changed:**
- Uses `physicalLocationRef` and `shelfRef` for all operations
- Updates both reference fields and legacy fields
- Maintains backwards compatibility

**Relocation Creation:**
```typescript
const relocationData = {
  // Reference fields (new structure)
  partRef: selectedPart.id,
  fromLocationRef: selectedPart.physicalLocationRef,
  toLocationRef: selectedLocation.id,
  fromShelfRef: selectedPart.shelfRef,
  toShelfRef: selectedShelfId,
  
  // Legacy fields (backwards compatibility)
  partNumber: selectedPart.partNumber,
  partName: selectedPart.partName,
  fromLocation: selectedPart.physicalLocation,
  toLocation: selectedLocation.name,
  fromShelf: selectedPart.shelfAddress,
  toShelf: newShelf,
  qtyToRelocate: parseInt(qtyToRelocate),
  
  // Metadata
  status: "activated",
  date: new Date().toISOString(),
  createdAt: serverTimestamp(),
  createdBy: "current_user"
};
```

**Part Update After Relocation:**
```typescript
await updateDoc(partRef, {
  shelfAddress: newShelf,
  shelfRef: toShelfRef,
  physicalLocation: selectedLocation.name,
  physicalLocationRef: toLocationRef
});
```

### 5. **Submit Button Logic**

**Updated Validation:**
```typescript
const canSubmit = 
  selectedLocation &&      // Location selected
  selectedPart &&          // Part selected
  qtyToRelocate &&         // Quantity entered
  selectedShelfId &&       // New shelf selected
  !quantityError &&        // No validation errors
  !isSubmitting;           // Not currently submitting
```

**Button Behavior:**
- Enabled (#4C68B0) when all conditions met
- Disabled (#C6C6C6) otherwise
- Shows proper enabled/disabled states

### 6. **Error Handling**

**Firebase Level:**
```typescript
const handleSubmit = async () => {
  // Final validation before submit
  const qty = parseInt(qtyToRelocate);
  const available = selectedPart?.currentAvailability || 0;
  
  if (!qtyToRelocate || isNaN(qty) || qty <= 0) {
    setQuantityError("Please enter a valid quantity.");
    return;
  }
  
  if (qty > available) {
    setQuantityError("Quantity exceeds available stock. Please enter a lower amount.");
    return;
  }

  // Proceed with relocation...
};
```

**Error Prevention:**
- ✅ Validates before attempting Firebase write
- ✅ Shows error message to user
- ✅ Prevents invalid data from being saved
- ✅ Error remains visible until corrected

### 7. **UI/UX Improvements**

**Click Outside to Close:**
```typescript
useEffect(() => {
  const handleClickOutside = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    if (!target.closest('[data-dropdown]')) {
      setIsLocationDropdownOpen(false);
      setIsShelfDropdownOpen(false);
    }
  };
  
  document.addEventListener('mousedown', handleClickOutside);
  return () => document.removeEventListener('mousedown', handleClickOutside);
}, []);
```

**Improved Input Field:**
- Changed from `type="text"` to `type="number"` for quantity
- Better placeholder text: "Please enter a quantity"
- Input text color changes from gray to black when typing

**Shelf Display:**
- Shows "Select new shelf" as placeholder
- Displays selected shelf label when chosen
- Proper alignment and spacing

## 📊 Data Flow

### Complete User Flow:

1. **User Opens Page**
   - Loads physical locations from Firebase
   - Sets default location (first in list)
   - UI ready for part selection

2. **User Adds Part**
   - Navigates to Select Parts page
   - Selects a part
   - Returns to New Parts Relocation with part data

3. **User Selects Location** (Optional)
   - Clicks Physical Location dropdown
   - Sees all available locations
   - Selects new location
   - Available shelves reload for new location

4. **User Enters Quantity**
   - Types quantity in field
   - Real-time validation checks:
     - Is it a number?
     - Is it greater than 0?
     - Does it exceed available stock?
   - Error message appears if invalid
   - Submit button disables if error

5. **User Selects New Shelf**
   - Clicks New Shelf dropdown
   - Sees shelves for selected location (excluding current shelf)
   - Selects new shelf
   - Shelf label displayed in field

6. **User Submits**
   - Final validation runs
   - If valid:
     - Creates relocation document with references
     - Updates part's location and shelf references
     - Returns to Parts Relocation list
   - If invalid:
     - Shows error message
     - Prevents submission

## 🔧 Technical Details

### State Management

```typescript
// Location & Shelf state
const [physicalLocations, setPhysicalLocations] = useState<PhysicalLocation[]>([]);
const [selectedLocation, setSelectedLocation] = useState<PhysicalLocation | null>(null);
const [availableShelves, setAvailableShelves] = useState<Shelf[]>([]);
const [isLocationDropdownOpen, setIsLocationDropdownOpen] = useState(false);
const [isShelfDropdownOpen, setIsShelfDropdownOpen] = useState(false);

// Part editing state
const [qtyToRelocate, setQtyToRelocate] = useState("");
const [newShelf, setNewShelf] = useState("");
const [selectedShelfId, setSelectedShelfId] = useState("");
const [quantityError, setQuantityError] = useState("");
const [isSubmitting, setIsSubmitting] = useState(false);
```

### Key Functions

| Function | Purpose |
|----------|---------|
| `handleLocationSelect()` | Updates selected location and reloads shelves |
| `handleShelfSelect()` | Updates selected shelf |
| `handleQtyChange()` | Validates quantity in real-time |
| `handleSubmit()` | Validates and creates relocation |
| `handleDeletePart()` | Clears all part data |

### Dependencies

```typescript
import { 
  fetchAllPhysicalLocations, 
  fetchShelvesByLocation, 
  type PhysicalLocation, 
  type Shelf 
} from "../utils/firebase/relationalData";
```

## 🎨 Design Consistency

### Error Message Styling
- Font: IBM Plex Sans Light
- Size: 12px
- Color: #da1e28 (Error red)
- Matches existing error field style in the app

### Dropdown Styling
- Background: White
- Border: #e0e0e0
- Shadow: Standard shadow-lg
- Hover: #f4f4f4
- Font: IBM Plex Sans Regular, 14px
- Max height: 200px with scroll

### Input Field
- Type: number (for quantity validation)
- Placeholder color: #9b9b9b
- Text color: #161616
- Font: IBM Plex Sans Light, 14px

## 📝 Example Usage

### Scenario 1: Valid Relocation
```
1. Part selected: Brake Pad (Current: BMW Parts / B1, Qty: 30)
2. User selects: Main Warehouse
3. Available shelves: A1, A2, C1 (B1 excluded from dropdown)
4. User enters: 5 (quantity)
5. User selects: A1 (new shelf)
6. Submit enabled ✅
7. Relocation created successfully
8. Part updated: Main Warehouse / A1
```

### Scenario 2: Quantity Exceeds Stock
```
1. Part selected: Oil Filter (Current: BMW Parts / DEFB, Qty: 17)
2. User enters: 25 (quantity)
3. Error appears: "Quantity exceeds available stock. Please enter a lower amount."
4. Submit button disabled ❌
5. User corrects: 10 (quantity)
6. Error clears
7. Submit enabled ✅
```

### Scenario 3: No Available Shelves
```
1. Part selected: Test Part (Current: BMW Parts / Only shelf)
2. User clicks New Shelf dropdown
3. Dropdown shows: "No available shelves"
4. Submit remains disabled ❌
5. User must select different location or add new shelves
```

## ✅ Testing Checklist

- [x] Physical location dropdown loads from Firebase
- [x] Location dropdown shows all locations
- [x] Selecting location updates UI
- [x] Shelf dropdown loads based on location
- [x] Current shelf excluded from shelf list
- [x] Quantity validation works in real-time
- [x] Error message appears for invalid quantity
- [x] Error message appears when exceeding stock
- [x] Submit button disables when validation fails
- [x] Submit button enables when all valid
- [x] Relocation creates with correct references
- [x] Part updates with new location/shelf
- [x] Dropdowns close when clicking outside
- [x] Data maintains backwards compatibility

## 🚀 Benefits

### For Users
- ✅ **Clear Feedback**: Real-time validation prevents errors
- ✅ **Smart Filtering**: Only see relevant shelves
- ✅ **Error Prevention**: Can't submit invalid data
- ✅ **Better UX**: Dropdowns close automatically

### For Data
- ✅ **Data Integrity**: All relocations use proper references
- ✅ **Consistency**: References always valid
- ✅ **Backwards Compatible**: Legacy fields maintained
- ✅ **Relational**: Proper document relationships

### For Developers
- ✅ **Type Safe**: Full TypeScript support
- ✅ **Reusable**: Uses existing utility functions
- ✅ **Maintainable**: Clear separation of concerns
- ✅ **Extensible**: Easy to add new features

## 📚 Related Documentation

- [Firebase Relational Structure](/FIREBASE_RELATIONAL_STRUCTURE.md)
- [Database Update Summary](/DATABASE_UPDATE_SUMMARY.md)
- [Relational Database Implementation](/RELATIONAL_DATABASE_IMPLEMENTATION.md)

## 🎉 Summary

The New Parts Relocation page now features:
- ✅ Dynamic location dropdown from Firebase
- ✅ Dynamic shelf dropdown with smart filtering
- ✅ Real-time quantity validation
- ✅ Inline error messages
- ✅ Proper database relationships
- ✅ Backwards compatibility
- ✅ Excellent UX with click-outside-to-close
- ✅ Complete error handling
- ✅ Maintains existing design system

All requirements have been successfully implemented! 🚀
