# Parts Consolidation - Quick Start Guide

## What Changed?

The parts database structure has been updated to eliminate duplicates:

**Before:** WH340 existed as 3 separate documents (one per shelf)  
**After:** WH340 exists as 1 document with a `shelfStocks` array

## How to Migrate NOW

### Option 1: Use the Migration Panel (Easiest) ✅

A **blue migration panel** now appears in the bottom-right corner of your app.

**Steps:**
1. Open your app (the panel is visible on all screens)
2. Click **"Check Migration Status"**
3. If migration is needed, you'll see two options:

   **Option A - Preserve Your Data:**
   - Click **"Run Migration (Preserve Data)"**
   - This consolidates existing duplicates into the new structure
   - All data is preserved
   - Takes a few seconds

   **Option B - Fresh Start:**
   - Click **"Clear & Reseed (Fresh Start)"**
   - Deletes all parts and creates fresh consolidated test data
   - Faster and cleaner
   - **Recommended if you're just testing**

### Option 2: Automatic Migration on App Load

The app will now **automatically check** for duplicates on startup and migrate if needed.

Just refresh your app and check the browser console for:
```
✅ Migration completed successfully!
   Migrated X unique parts
```

## What You'll See After Migration

### In Firebase Console
Navigate to `parts` collection and you'll see:

```javascript
// Document: WH340
{
  partNumber: "WH340",
  partName: "ALL TERRAIN WHEEL",
  physicalLocationRef: "bmwParts",
  shelfStocks: [
    { shelfRef: "shelfB1", currentAvail: 30 },
    { shelfRef: "shelfB2", currentAvail: 35 },
    { shelfRef: "shelfB6", currentAvail: 34 }
  ]
}
```

### In the App UI
**No visible changes!** The UI looks exactly the same:
- Select Parts still shows individual shelf rows
- WH340 - Shelf B1 - 30 units ✅
- WH340 - Shelf B2 - 35 units ✅
- WH340 - Shelf B6 - 34 units ✅

### In Relocation Flow
**Major improvement:**
- When you select "WH340 on B1", the "New Shelf" dropdown now shows **only B2 and B6** (shelves with the same part)
- This is the correct behavior you requested!

## Verify Migration Worked

### Step 1: Check Firebase Console
1. Open Firebase Console
2. Go to Firestore Database
3. Open `parts` collection
4. Find document `WH340`
5. You should see the `shelfStocks` array

### Step 2: Test in the App
1. Go to Parts Relocation
2. Click "New Parts Relocation"
3. Click "Select Parts"
4. Select "WH340 - Shelf B1"
5. In "New Shelf" dropdown, you should ONLY see B2 and B6

## Troubleshooting

### "Migration didn't run"
- Check browser console for errors
- Try clicking "Clear & Reseed" in the migration panel

### "Can't see the migration panel"
- Make sure you saved App.tsx with the DatabaseMigrationPanel import
- Refresh your browser

### "Parts not showing in Select Parts"
- Check browser console for errors
- The fetchAllPartShelfInstances() function might be failing
- Try "Clear & Reseed" to start fresh

### "Shelves dropdown is empty"
- Make sure the part has multiple shelf locations
- WH340 should show B1, B2, B6 in different rows

## Remove the Migration Panel Later

Once migration is complete, you can remove the panel:

**In App.tsx, remove these lines:**
```typescript
import DatabaseMigrationPanel from "./components/DatabaseMigrationPanel";

// And in the return statement:
<DatabaseMigrationPanel />
```

## What Happens During Migration?

1. **Fetch** all existing part documents
2. **Group** by partNumber (e.g., all WH340 documents together)
3. **Consolidate** into one document with shelfStocks array
4. **Delete** old duplicate documents
5. **Create** new consolidated document with deterministic ID

### Example:
```
Before:
- parts/abc123 → { partNumber: "WH340", shelfRef: "B1", currentAvail: 30 }
- parts/def456 → { partNumber: "WH340", shelfRef: "B2", currentAvail: 35 }
- parts/ghi789 → { partNumber: "WH340", shelfRef: "B6", currentAvail: 34 }

After:
- parts/WH340 → { 
    partNumber: "WH340", 
    shelfStocks: [
      { shelfRef: "B1", currentAvail: 30 },
      { shelfRef: "B2", currentAvail: 35 },
      { shelfRef: "B6", currentAvail: 34 }
    ]
  }
```

## Expected Results

### Before Consolidation:
- ❌ 6 documents in parts collection (duplicates)
- ❌ "New Shelf" shows all shelves from location
- ❌ Can relocate to shelves that don't have the same part

### After Consolidation:
- ✅ 4 documents in parts collection (unique parts only)
- ✅ "New Shelf" shows only shelves with the same part number
- ✅ Correct warehouse logic enforced
- ✅ Single source of truth for each part

## Need Help?

Check the full documentation in:
- `/PARTS_CONSOLIDATION_MIGRATION.md` - Complete technical details
- Browser console - Look for migration logs
- Firebase Console - Verify data structure

## Quick Commands

```javascript
// In browser console (if you want to run manually):

// Check if migration needed
await checkIfMigrationNeeded()

// Run migration
await migratePartsToConsolidatedStructure()

// Clear and reseed
await clearParts()
await seedParts()
```
