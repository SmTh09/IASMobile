# External Backend Integration Guide

## Overview
This application is now configured to connect to your own external backend API instead of Supabase. Your backend should have proper database tables for structured data.

## Configuration

### 1. Update API Endpoint
Edit `/utils/api.ts` and update these constants:

```typescript
const API_BASE = 'https://your-backend-api.com/api';  // Your backend URL
const API_KEY = '';  // Your API key (if required)
```

### 2. Required Database Tables

Your backend should have the following tables with this structure:

#### **Users Table**
```sql
CREATE TABLE users (
  id VARCHAR(255) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### **Customers Table**
```sql
CREATE TABLE customers (
  id VARCHAR(255) PRIMARY KEY,
  user_id VARCHAR(255) REFERENCES users(id),
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### **Vehicles Table**
```sql
CREATE TABLE vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id VARCHAR(255) REFERENCES customers(id),
  license_plate VARCHAR(50) NOT NULL UNIQUE,
  brand VARCHAR(100) NOT NULL,
  model VARCHAR(100) NOT NULL,
  image_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### **Appointments Table**
```sql
CREATE TABLE appointments (
  id VARCHAR(255) PRIMARY KEY,
  customer_id VARCHAR(255) REFERENCES customers(id),
  customer_name VARCHAR(255) NOT NULL,
  vehicle_id INT REFERENCES vehicles(id),
  license_plate VARCHAR(50) NOT NULL,
  brand VARCHAR(100) NOT NULL,
  model VARCHAR(100) NOT NULL,
  mileage VARCHAR(50),
  measurement VARCHAR(50),
  appointment_date TIMESTAMP NOT NULL,
  time_slot VARCHAR(50) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### **Job Lines Table**
```sql
CREATE TABLE job_lines (
  id INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id VARCHAR(255) REFERENCES appointments(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  order_index INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3. Required API Endpoints

Your backend must implement these REST API endpoints:

#### **Create Appointment**
```
POST /api/appointments
Content-Type: application/json
Authorization: Bearer {API_KEY} (if required)

Request Body:
{
  "customerId": "customer-theo-floyd",
  "customerName": "Theo Floyd",
  "vehicle": {
    "licensePlate": "TK-271-GT",
    "brand": "Audi",
    "model": "RS3",
    "image": "https://..."
  },
  "jobLines": [
    { "id": 1, "text": "Oil change" },
    { "id": 2, "text": "Brake inspection" }
  ],
  "mileage": "15000",
  "measurement": "Kilometers",
  "date": "2025-10-20T10:00:00.000Z",
  "timeSlot": "10:00 - 11:00"
}

Response:
{
  "success": true,
  "appointment": { ...appointment object... },
  "appointmentCount": 5
}
```

#### **Get Appointments**
```
GET /api/appointments/{customerId}
Authorization: Bearer {API_KEY} (if required)

Response:
{
  "success": true,
  "appointments": [ ...array of appointments... ]
}
```

#### **Get Appointment Count**
```
GET /api/appointments/{customerId}/count
Authorization: Bearer {API_KEY} (if required)

Response:
{
  "success": true,
  "count": 5
}
```

#### **Update Appointment**
```
PATCH /api/appointments/{customerId}/{appointmentId}
Content-Type: application/json
Authorization: Bearer {API_KEY} (if required)

Request Body:
{
  "status": "completed"
}

Response:
{
  "success": true,
  "appointment": { ...updated appointment... }
}
```

#### **Delete Appointment**
```
DELETE /api/appointments/{customerId}/{appointmentId}
Authorization: Bearer {API_KEY} (if required)

Response:
{
  "success": true,
  "appointmentCount": 4
}
```

### 4. CORS Configuration

Make sure your backend enables CORS for this frontend:

```javascript
// Example for Express.js
app.use(cors({
  origin: ['http://localhost:3000', 'https://your-frontend-domain.com'],
  methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  credentials: true
}));
```

### 5. Authentication (Optional)

If your backend requires authentication:
1. Update the `API_KEY` constant in `/utils/api.ts`
2. Or implement a proper auth flow with login/token management

### 6. Testing

Test your backend endpoints with curl or Postman before integrating:

```bash
# Test appointment creation
curl -X POST https://your-backend-api.com/api/appointments \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "customerId": "test-customer",
    "customerName": "Test User",
    "vehicle": {...},
    ...
  }'
```

## Framework Examples

### Node.js/Express Example
```javascript
const express = require('express');
const app = express();

app.post('/api/appointments', async (req, res) => {
  const { customerId, customerName, vehicle, jobLines, mileage, measurement, date, timeSlot } = req.body;
  
  // Insert into database
  const appointmentId = generateUniqueId();
  await db.query('INSERT INTO appointments ...', [...]);
  
  // Insert job lines
  for (let jobLine of jobLines) {
    await db.query('INSERT INTO job_lines ...', [...]);
  }
  
  res.json({
    success: true,
    appointment: { id: appointmentId, ... },
    appointmentCount: await getAppointmentCount(customerId)
  });
});
```

### Python/Flask Example
```python
from flask import Flask, request, jsonify

@app.route('/api/appointments', methods=['POST'])
def create_appointment():
    data = request.json
    
    # Insert into database
    appointment_id = str(uuid.uuid4())
    cursor.execute('INSERT INTO appointments ...', [...])
    
    # Insert job lines
    for job_line in data['jobLines']:
        cursor.execute('INSERT INTO job_lines ...', [...])
    
    return jsonify({
        'success': True,
        'appointment': {...},
        'appointmentCount': get_appointment_count(data['customerId'])
    })
```

## Troubleshooting

- **CORS errors**: Check your backend CORS configuration
- **401 Unauthorized**: Verify your API_KEY is correct
- **Network errors**: Check the API_BASE URL is correct
- **Data not saving**: Check your database connection and table schemas
- **Check browser console**: All errors are logged with context

## Next Steps

1. Set up your database with the tables above
2. Create the backend API endpoints
3. Update `/utils/api.ts` with your backend URL and API key
4. Test the integration!
