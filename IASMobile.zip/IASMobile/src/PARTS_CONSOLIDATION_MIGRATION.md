# Parts Database Consolidation - Migration Guide

## Overview

This document describes the major database restructure that consolidates duplicate part documents into a single canonical structure with a `shelfStocks` array.

## Problem Statement

Previously, the same part (e.g., Part No: WH340) existed as **multiple separate documents** in the `parts` collection — one document per shelf location. This created:

- Data duplication and inconsistency
- Complex queries and data management
- Broken relational logic for relocations
- Difficulty tracking total inventory across all shelves for a single part

## New Structure

### Before (Old Structure)
```javascript
// Three separate documents for the same part:
parts/doc1: {
  partNumber: "WH340",
  partName: "ALL TERRAIN WHEEL",
  physicalLocationRef: "bmwParts",
  shelfRef: "shelfB1",
  currentAvailability: 30
}

parts/doc2: {
  partNumber: "WH340",
  partName: "ALL TERRAIN WHEEL", 
  physicalLocationRef: "bmwParts",
  shelfRef: "shelfB2",
  currentAvailability: 35
}

parts/doc3: {
  partNumber: "WH340",
  partName: "ALL TERRAIN WHEEL",
  physicalLocationRef: "bmwParts",
  shelfRef: "shelfB6",
  currentAvailability: 34
}
```

### After (New Structure)
```javascript
// One canonical document with shelfStocks array:
parts/WH340: {
  partNumber: "WH340",
  partName: "ALL TERRAIN WHEEL",
  description: "ALL TERRAIN WHEEL",
  physicalLocationRef: "bmwParts",
  shelfStocks: [
    { shelfRef: "shelfB1", currentAvail: 30 },
    { shelfRef: "shelfB2", currentAvail: 35 },
    { shelfRef: "shelfB6", currentAvail: 34 }
  ],
  // Legacy fields for backwards compatibility:
  shelfRef: "shelfB1",
  shelfAddress: "B1",
  currentAvailability: 30,
  physicalLocation: "BMW Parts"
}
```

## Updated Interfaces

### ShelfStock Interface
```typescript
export interface ShelfStock {
  shelfRef: string;
  currentAvail: number;
  // Populated data
  shelfData?: Shelf;
}
```

### Part Interface
```typescript
export interface Part {
  id: string;
  partNumber: string;
  partName: string;
  description?: string;
  physicalLocationRef: string;
  shelfStocks: ShelfStock[]; // New array structure
  // Legacy fields (for backwards compatibility)
  physicalLocation?: string;
  shelfAddress?: string;
  currentAvailability?: number;
  shelfRef?: string;
  // Populated data
  physicalLocationData?: PhysicalLocation;
}
```

### PartShelfInstance Interface (for UI Display)
```typescript
// Represents a specific shelf instance of a part for UI display
export interface PartShelfInstance extends Part {
  currentShelfRef: string; // The specific shelf for this instance
  currentAvail: number; // The availability on this specific shelf
  shelfData?: Shelf; // Populated shelf data for this instance
}
```

### Updated Relocation Interface
```typescript
export interface Relocation {
  id: string;
  partRef: string; // Reference to parent part document
  fromLocationRef: string;
  toLocationRef: string;
  fromShelfRef: string; // Source shelf within the part
  toShelfRef: string; // Target shelf within the part
  quantityRelocated: number; // NEW: explicit quantity field
  date: string;
  status: string;
  timestamp?: any;
  createdBy?: string;
  // Populated data...
}
```

## Migration Process

### Step 1: Clear Existing Data (if starting fresh)
```typescript
import { clearParts } from './utils/firebase/seedParts';
await clearParts();
```

### Step 2: Seed New Consolidated Structure
```typescript
import { seedParts } from './utils/firebase/seedParts';
await seedParts();
```

### Step 3: Migrate Existing Data (if preserving data)
```typescript
import { migratePartsToConsolidatedStructure } from './utils/firebase/migrateParts';
const result = await migratePartsToConsolidatedStructure();
```

The migration script will:
1. Fetch all existing part documents
2. Group them by `partNumber`
3. Create consolidated documents with `shelfStocks` arrays
4. Delete old duplicate documents
5. Use deterministic document IDs based on part number

### Using the UI Button

The `SeedPartsButton` component now includes a "Migrate to New Structure" button that:
- Prompts for confirmation
- Runs the migration
- Shows detailed results including any errors

## Key Changes by Component

### 1. SelectParts Component
**Change**: Now displays shelf-specific rows from consolidated parts

```typescript
// Fetches expanded part-shelf instances
const instances = await fetchAllPartShelfInstances();

// Each instance represents one shelf's stock of a part
// WH340 on B1 → separate row
// WH340 on B2 → separate row  
// WH340 on B6 → separate row
```

**Visual**: No change to user — still sees individual shelf rows

### 2. NewPartsRelocation Component
**Change**: Uses parent part ID for relocations

```typescript
// Tracks both UI ID and parent part ID
interface Part {
  id: string; // Composite ID for UI (partId_shelfRef)
  parentPartId?: string; // Actual parent part document ID
  // ...
}

// Uses parentPartId for relocation
createRelocation({
  partId: part.parentPartId || part.id,
  fromShelfId: part.shelfRef,
  toShelfId: toShelfId,
  // ...
});
```

### 3. Relocation Creation Logic
**Change**: Updates `shelfStocks` array instead of creating/updating separate documents

```typescript
// Old behavior: Create/update separate part documents
// New behavior: Update shelfStocks array in single parent document

// Example relocation: 10 units from B1 to B2
shelfStocks: [
  { shelfRef: "B1", currentAvail: 30 - 10 = 20 },
  { shelfRef: "B2", currentAvail: 35 + 10 = 45 },
  { shelfRef: "B6", currentAvail: 34 }
]

// If quantity reaches 0, the shelf entry is removed
// If target shelf doesn't exist, it's added to the array
```

## New Utility Functions

### `fetchAllPartShelfInstances()`
Expands parts into shelf-specific instances for UI display.

```typescript
const instances = await fetchAllPartShelfInstances();
// Returns array of PartShelfInstance objects
```

### `fetchPartShelfInstancesByLocation(locationId)`
Fetches shelf instances filtered by location.

```typescript
const instances = await fetchPartShelfInstancesByLocation("bmwParts");
```

### `fetchShelvesWithSamePartNumber(partNumber, currentShelfId?)`
Finds all shelves containing a specific part number (for relocation dropdown).

```typescript
const shelves = await fetchShelvesWithSamePartNumber("WH340", "shelfB1");
// Returns [shelfB2, shelfB6] (excluding B1)
```

### `migratePartsToConsolidatedStructure()`
Performs the migration from old to new structure.

```typescript
const result = await migratePartsToConsolidatedStructure();
// Returns { success, message, migratedCount, errors }
```

### `checkIfMigrationNeeded()`
Checks if duplicate part numbers exist.

```typescript
const needed = await checkIfMigrationNeeded();
// Returns true if duplicates found
```

## Benefits of New Structure

### ✅ Data Integrity
- Single source of truth for each part
- No duplicate part numbers
- Atomic updates across all shelves

### ✅ Simplified Queries
- Find a part by part number: O(1) lookup
- Get all shelf locations for a part: Single document read
- Calculate total inventory: Sum shelfStocks array

### ✅ Relocation Logic
- Update quantities in-place within single document
- Atomic operations ensure data consistency
- Clear audit trail with relocation records

### ✅ Scalability
- Fewer documents in collection
- Better Firestore query performance
- Lower read costs

## Backwards Compatibility

The new structure maintains legacy fields to ensure compatibility during transition:

```typescript
{
  // New fields
  shelfStocks: [...],
  
  // Legacy fields (using first shelf stock)
  shelfRef: shelfStocks[0].shelfRef,
  shelfAddress: "B1",
  currentAvailability: shelfStocks[0].currentAvail,
  physicalLocation: "BMW Parts"
}
```

## Testing Checklist

- [ ] Clear parts collection
- [ ] Seed new consolidated parts
- [ ] Verify parts display correctly in SelectParts
- [ ] Select a part with multiple shelf locations
- [ ] Verify shelves with same part number appear in dropdown
- [ ] Create a relocation between shelves
- [ ] Verify shelfStocks array updated correctly
- [ ] Verify relocation record created
- [ ] Verify part quantities updated atomically
- [ ] Test edge cases:
  - [ ] Relocating all quantity (should remove shelf entry)
  - [ ] Relocating to new shelf (should add shelf entry)
  - [ ] Multiple relocations in sequence

## Troubleshooting

### Issue: Parts not showing in SelectParts
**Solution**: Run `fetchAllPartShelfInstances()` — this expands parts into shelf rows

### Issue: Relocation fails with "Part not found"
**Solution**: Ensure `parentPartId` is set correctly in PartData

### Issue: Duplicate parts still exist
**Solution**: Run migration script to consolidate

### Issue: ShelfStocks array not updating
**Solution**: Check that `createRelocation()` is using new logic in `relocations.ts`

## Files Modified

- `/utils/firebase/relationalData.ts` - Added ShelfStock, PartShelfInstance interfaces and utility functions
- `/utils/firebase/seedParts.ts` - Updated to seed consolidated parts
- `/utils/firebase/migrateParts.ts` - New migration script
- `/utils/firebase/relocations.ts` - Complete rewrite to work with shelfStocks array
- `/components/SelectParts.tsx` - Updated to use PartShelfInstance
- `/components/NewPartsRelocation.tsx` - Updated to track parentPartId
- `/components/SeedPartsButton.tsx` - Added migration button

## Next Steps

1. **Test thoroughly** with the new structure
2. **Monitor** relocation operations for data consistency
3. **Consider** adding total inventory calculations
4. **Plan** for archiving old relocation records if needed
5. **Document** any additional edge cases discovered

## Questions?

This is a significant architectural change. If you encounter issues:
1. Check the console for detailed error messages
2. Verify document structure in Firebase console
3. Use the migration script to consolidate any remaining duplicates
4. Refer to the TypeScript interfaces for expected data shapes
