# Parts Selection Filtering Logic

## 🎯 Overview

The Parts Selection page now implements intelligent filtering to ensure only relocatable parts are displayed. Parts that are already at the final destination (Main Warehouse) cannot be relocated and are excluded from the selection list.

## ✅ Filtering Rules

### 1. **Main Warehouse Exclusion**

**Rule:** Parts located in "Main Warehouse" cannot be selected for relocation.

**Reasoning:**
- Main Warehouse is the final destination for all parts
- Parts that are already there don't need to be relocated
- Prevents unnecessary relocation cycles

**Implementation:**
```typescript
const isMainWarehouse = 
  part.physicalLocationRef === "mainWarehouse" ||
  part.physicalLocation?.toLowerCase().includes("main warehouse");
```

**Checks Both:**
- ✅ Reference field: `physicalLocationRef === "mainWarehouse"`
- ✅ Legacy field: `physicalLocation.includes("main warehouse")`

### 2. **Physical Location Required**

**Rule:** Parts must have a physical location assigned to be relocatable.

**Reasoning:**
- Cannot relocate a part without knowing its current location
- Ensures data integrity
- Prevents orphaned parts

**Implementation:**
```typescript
const hasLocation = part.physicalLocationRef || part.physicalLocation;
```

**Checks Both:**
- ✅ Reference field: `physicalLocationRef` exists
- ✅ Legacy field: `physicalLocation` exists

## 📊 Complete Filtering Logic

```typescript
const partsData: PartData[] = partsSnapshot.docs
  .map((doc) => {
    const data = doc.data();
    return {
      id: doc.id,
      partNumber: data.partNumber || "",
      partName: data.partName || data.name || "",
      physicalLocation: data.physicalLocation || "BMW Parts",
      shelfAddress: data.shelfAddress || "",
      currentAvailability: data.currentAvailability || data.availability || 0,
      physicalLocationRef: data.physicalLocationRef,
      shelfRef: data.shelfRef,
    };
  })
  .filter((part) => {
    // Exclude parts that are in Main Warehouse (final destination)
    const isMainWarehouse = 
      part.physicalLocationRef === "mainWarehouse" ||
      part.physicalLocation?.toLowerCase().includes("main warehouse");
    
    // Only include parts that:
    // 1. Are NOT in Main Warehouse
    // 2. Have a physical location assigned
    return !isMainWarehouse && 
           (part.physicalLocationRef || part.physicalLocation);
  });
```

## 🔍 Examples

### ✅ Parts That WILL Appear

**Example 1: BMW Parts Location**
```json
{
  "partNumber": "83210398511",
  "partName": "test package part",
  "physicalLocation": "BMW Parts",
  "physicalLocationRef": "bmwParts",
  "shelfRef": "shelfDEFB"
}
```
✅ **Shows in list** - Can be relocated to Main Warehouse

**Example 2: Custom Location**
```json
{
  "partNumber": "WH340",
  "partName": "ALL TERRAIN WHEEL",
  "physicalLocation": "BMW Parts",
  "physicalLocationRef": "bmwParts",
  "shelfRef": "shelfB1"
}
```
✅ **Shows in list** - Not in Main Warehouse, has location

### ❌ Parts That WILL NOT Appear

**Example 1: Already in Main Warehouse**
```json
{
  "partNumber": "ABC123",
  "partName": "Completed Part",
  "physicalLocation": "Main Warehouse",
  "physicalLocationRef": "mainWarehouse",
  "shelfRef": "shelfA1"
}
```
❌ **Hidden from list** - Already at final destination

**Example 2: Main Warehouse Reference**
```json
{
  "partNumber": "DEF456",
  "partName": "Stored Part",
  "physicalLocation": "Main Warehouse",
  "physicalLocationRef": "mainWarehouse",
  "shelfRef": "shelfC1"
}
```
❌ **Hidden from list** - Reference indicates Main Warehouse

**Example 3: No Location**
```json
{
  "partNumber": "GHI789",
  "partName": "Orphaned Part",
  "physicalLocation": null,
  "physicalLocationRef": null,
  "shelfRef": null
}
```
❌ **Hidden from list** - No physical location assigned

**Example 4: Legacy Main Warehouse (Case Insensitive)**
```json
{
  "partNumber": "JKL012",
  "partName": "Old Part",
  "physicalLocation": "main warehouse",
  "physicalLocationRef": null
}
```
❌ **Hidden from list** - Legacy field contains "main warehouse"

## 🏗️ Data Flow

### On Page Load

```
1. User navigates to Select Parts
   ↓
2. Fetch all parts from Firebase
   ↓
3. Map parts to include all fields
   ↓
4. Filter out:
   - Parts with physicalLocationRef = "mainWarehouse"
   - Parts with physicalLocation containing "main warehouse"
   - Parts without any physical location
   ↓
5. Display filtered list
```

### Part Selection

```
1. User sees only relocatable parts
   ↓
2. User selects a part (must be from filtered list)
   ↓
3. Part data passed to New Parts Relocation
   ↓
4. User can relocate part to any location (including Main Warehouse)
```

## 🎨 User Experience

### When No Parts Available

If all parts are in Main Warehouse or have no location:
- Shows "NotFound" component
- User cannot proceed
- Clear indication that no parts need relocation

### Search Functionality

Search works on filtered parts only:
```typescript
// Search only includes relocatable parts
parts.filter(
  (part) =>
    part.partNumber.toLowerCase().includes(query) ||
    part.partName.toLowerCase().includes(query) ||
    part.shelfAddress.toLowerCase().includes(query)
)
```

## 🔧 Technical Details

### Interface Updates

```typescript
export interface PartData {
  id: string;
  partNumber: string;
  partName: string;
  physicalLocation: string;
  shelfAddress: string;
  currentAvailability: number;
  physicalLocationRef?: string;  // NEW: Reference field
  shelfRef?: string;             // NEW: Reference field
}
```

### Backwards Compatibility

The filtering logic checks BOTH reference and legacy fields:

| Field | Reference | Legacy | Result |
|-------|-----------|--------|--------|
| Location | `physicalLocationRef` | `physicalLocation` | Checks both |
| Main Warehouse | `"mainWarehouse"` | `"Main Warehouse"` | Case-insensitive |
| No Location | `null/undefined` | `null/undefined` | Excludes |

### Case Sensitivity

```typescript
// Case-insensitive check for legacy field
part.physicalLocation?.toLowerCase().includes("main warehouse")
```

Matches:
- "Main Warehouse"
- "main warehouse"
- "MAIN WAREHOUSE"
- "Main warehouse"

## 📝 Business Logic

### Relocation Workflow

```
BMW Parts → [Relocate] → Main Warehouse (Final Destination)
    ↓                           ↓
 Relocatable              Not Relocatable
 (Shows in list)         (Hidden from list)
```

### One-Way Flow

```
Source Locations        →        Main Warehouse
(BMW Parts, etc.)                (Final Destination)
     ✅ Can relocate              ❌ Cannot relocate
```

## 🚀 Benefits

### For Users
- ✅ **Clear Workflow**: Only see parts that need relocation
- ✅ **Prevents Errors**: Can't select parts already at destination
- ✅ **Saves Time**: No unnecessary relocations
- ✅ **Better UX**: Focused list of actionable items

### For Data
- ✅ **Data Integrity**: Ensures valid relocations only
- ✅ **Logical Flow**: Enforces one-way relocation pattern
- ✅ **Clean Records**: No circular relocations
- ✅ **Audit Trail**: Clear movement from source to destination

### For System
- ✅ **Efficient**: Filters at data load time
- ✅ **Backwards Compatible**: Works with old and new data
- ✅ **Maintainable**: Simple, clear filtering logic
- ✅ **Extensible**: Easy to add new exclusion rules

## 🧪 Testing Scenarios

### Test 1: BMW Parts Part
```
Given: Part at BMW Parts location
When: User opens Select Parts
Then: Part appears in list
And: User can select and relocate it
```

### Test 2: Main Warehouse Part
```
Given: Part at Main Warehouse location
When: User opens Select Parts
Then: Part does NOT appear in list
And: User cannot select it
```

### Test 3: No Location Part
```
Given: Part without location
When: User opens Select Parts
Then: Part does NOT appear in list
And: User cannot select it
```

### Test 4: Search with Filtered Parts
```
Given: 5 parts at BMW Parts, 3 parts at Main Warehouse
When: User opens Select Parts
Then: Only 5 parts appear
When: User searches by part number
Then: Search only includes the 5 BMW Parts parts
```

### Test 5: All Parts in Main Warehouse
```
Given: All parts at Main Warehouse
When: User opens Select Parts
Then: NotFound component displays
And: Next button is disabled
And: User cannot proceed
```

## 📚 Related Documentation

- [Firebase Relational Structure](/FIREBASE_RELATIONAL_STRUCTURE.md)
- [New Parts Relocation Update](/NEW_PARTS_RELOCATION_UPDATE.md)
- [Database Update Summary](/DATABASE_UPDATE_SUMMARY.md)

## ✅ Summary

The Parts Selection page now intelligently filters parts to show only those that can be relocated:

✅ **Excludes** parts in Main Warehouse (final destination)  
✅ **Excludes** parts without a physical location  
✅ **Includes** parts at source locations (BMW Parts, etc.)  
✅ **Backwards compatible** with legacy data  
✅ **Case-insensitive** matching for safety  
✅ **User-friendly** with clear messaging  

This ensures a clean, logical relocation workflow from source locations to the final Main Warehouse destination! 🎉
