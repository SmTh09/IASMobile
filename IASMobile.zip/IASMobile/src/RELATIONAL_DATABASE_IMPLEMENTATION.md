# Parts Relocation - Relational Database Implementation

## 🎯 Overview

The Parts Relocation system now uses a fully relational Firebase Firestore database structure with proper document references, maintaining backwards compatibility with the legacy structure.

## 📋 Table of Contents

- [Quick Start](#quick-start)
- [Database Structure](#database-structure)
- [Key Features](#key-features)
- [Files Overview](#files-overview)
- [Usage Examples](#usage-examples)
- [Migration](#migration)
- [Troubleshooting](#troubleshooting)

## 🚀 Quick Start

The database is automatically initialized when you start the app:

1. **App loads** → Runs initialization in `App.tsx`
2. **Seeds locations & shelves** → Creates `physicalLocations` and `shelves` collections
3. **Removes duplicates** → Cleans up any duplicate parts
4. **Seeds parts** → Creates parts with references to locations and shelves
5. **Ready to use** → All relocation features work immediately

No manual setup required! ✨

## 🗂️ Database Structure

### Collections

```
firestore/
├── physicalLocations/      # Main storage locations
│   ├── bmwParts           # BMW Parts warehouse
│   └── mainWarehouse      # Main warehouse
│
├── shelves/               # Shelves within locations
│   ├── shelfDEFB         # Shelf DEFB at BMW Parts
│   ├── shelfB1           # Shelf B1 at BMW Parts
│   ├── shelfB2           # Shelf B2 at BMW Parts
│   ├── shelfA1           # Shelf A1 at Main Warehouse
│   └── ...               # More shelves
│
├── parts/                 # Individual parts
│   └── [auto-id]         # Part documents with references
│
└── relocations/          # Relocation records
    └── [auto-id]         # Relocation documents with references
```

### Document Relationships

```
┌─────────────────────┐
│  physicalLocations  │
│  - bmwParts        │◄─────┐
│  - mainWarehouse   │      │
└─────────────────────┘      │
                             │ physicalLocationRef
┌─────────────────────┐      │
│     shelves         │      │
│  - shelfDEFB       │──────┘
│  - shelfB1         │
└─────────────────────┘
         ▲
         │ shelfRef
         │
┌─────────────────────┐
│      parts          │
│  + partNumber      │
│  + partName        │
│  + shelfRef        │──────┐
│  + locationRef     │      │
└─────────────────────┘      │
         ▲                   │
         │ partRef           │
         │                   │
┌─────────────────────┐      │
│   relocations       │      │
│  + partRef         │──────┘
│  + fromShelfRef    │
│  + toShelfRef      │
│  + fromLocationRef │
│  + toLocationRef   │
└─────────────────────┘
```

## ✨ Key Features

### 1. **Proper Document References**

All relationships use document references (IDs), not string names:

```typescript
// ✅ Good (New approach)
{
  partRef: "part123",
  fromLocationRef: "bmwParts",
  toShelfRef: "shelfA1"
}

// ❌ Avoided (Old approach)
{
  partName: "Brake Pad",
  fromLocation: "BMW Parts",
  toShelf: "A1"
}
```

### 2. **Backwards Compatibility**

Both old and new data formats are supported:

```typescript
{
  // Reference fields (new)
  physicalLocationRef: "bmwParts",
  shelfRef: "shelfDEFB",
  
  // Legacy fields (maintained)
  physicalLocation: "BMW Parts",
  shelfAddress: "DEFB"
}
```

### 3. **Relational Data Fetching**

Utility functions automatically populate related data:

```typescript
const relocation = await fetchRelocationWithRelations("reloc001");

// Returns with all related data populated:
{
  id: "reloc001",
  partData: { partNumber: "...", partName: "..." },
  fromLocationData: { name: "BMW Parts", address: "..." },
  toLocationData: { name: "Main Warehouse", address: "..." },
  fromShelfData: { label: "DEFB" },
  toShelfData: { label: "A1" }
}
```

### 4. **Automatic Seeding**

Database is automatically seeded with:
- 2 physical locations (BMW Parts, Main Warehouse)
- 8 shelves (across both locations)
- 6 sample parts (with references)

### 5. **Data Integrity**

When a relocation is completed, the part's location is updated:

```typescript
// Part before relocation
{
  physicalLocationRef: "bmwParts",
  shelfRef: "shelfDEFB"
}

// Part after relocation completion
{
  physicalLocationRef: "mainWarehouse",
  shelfRef: "shelfA1"
}
```

## 📁 Files Overview

### Core Database Files

| File | Purpose |
|------|---------|
| `/utils/firebase/seedLocationsAndShelves.ts` | Seeds physical locations and shelves |
| `/utils/firebase/seedParts.ts` | Seeds parts with reference fields |
| `/utils/firebase/relationalData.ts` | Utility functions for relational queries |

### Component Files

| File | Changes |
|------|---------|
| `/components/NewPartsRelocation.tsx` | Creates relocations with references |
| `/components/PartsRelocation.tsx` | Displays relocations with relational data |
| `/App.tsx` | Initializes seeding on app load |

### Documentation Files

| File | Description |
|------|-------------|
| `/FIREBASE_RELATIONAL_STRUCTURE.md` | Complete database structure documentation |
| `/MIGRATION_GUIDE.md` | Guide for migrating existing data |
| `/FIRESTORE_SECURITY_RULES.md` | Updated security rules |
| `/RELATIONAL_DATABASE_IMPLEMENTATION.md` | This file |

## 💡 Usage Examples

### Fetching Locations

```typescript
import { fetchAllPhysicalLocations } from './utils/firebase/relationalData';

const locations = await fetchAllPhysicalLocations();
// Returns: [{ id: "bmwParts", name: "BMW Parts", ... }, ...]
```

### Fetching Shelves

```typescript
import { fetchAllShelves, fetchShelvesByLocation } from './utils/firebase/relationalData';

// Get all shelves with location data
const allShelves = await fetchAllShelves(true);

// Get shelves for specific location
const bmwShelves = await fetchShelvesByLocation("bmwParts");
```

### Fetching Parts with Relations

```typescript
import { fetchPartWithRelations } from './utils/firebase/relationalData';

const part = await fetchPartWithRelations("part123");

console.log(part.partNumber);
console.log(part.physicalLocationData.name); // "BMW Parts"
console.log(part.shelfData.label); // "DEFB"
```

### Creating a Relocation

```typescript
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "./utils/firebase/firestore";

const relocationData = {
  // Reference fields (required)
  partRef: selectedPart.id,
  fromLocationRef: "bmwParts",
  toLocationRef: "mainWarehouse",
  fromShelfRef: "shelfDEFB",
  toShelfRef: "shelfA1",
  
  // Legacy fields (for compatibility)
  partNumber: selectedPart.partNumber,
  fromLocation: "BMW Parts",
  toLocation: "Main Warehouse",
  
  // Metadata
  status: "activated",
  date: new Date().toISOString(),
  createdAt: serverTimestamp(),
  createdBy: "current_user"
};

await addDoc(collection(db, "relocations"), relocationData);
```

### Fetching Relocations with Relations

```typescript
import { fetchAllRelocationsWithRelations } from './utils/firebase/relationalData';

const relocations = await fetchAllRelocationsWithRelations();

relocations.forEach(rel => {
  console.log(`Moving ${rel.partData.partNumber}`);
  console.log(`From: ${rel.fromLocationData.name} / ${rel.fromShelfData.label}`);
  console.log(`To: ${rel.toLocationData.name} / ${rel.toShelfData.label}`);
});
```

## 🔄 Migration

### Automatic Migration

The app handles migration automatically:
- Old data continues to work (uses legacy fields)
- New data uses references
- No manual intervention needed

### Manual Migration

If you need to migrate existing data, see `/MIGRATION_GUIDE.md` for:
- Step-by-step migration scripts
- Backup procedures
- Rollback plans
- Verification steps

## 🔧 Troubleshooting

### Problem: Permission Denied Error

**Solution**: Update Firestore security rules to include new collections.

See `/FIRESTORE_SECURITY_RULES.md` for the complete rules.

```javascript
// Add these to your Firestore rules
match /physicalLocations/{locationId} {
  allow read: if true;
  allow write: if true;
}

match /shelves/{shelfId} {
  allow read: if true;
  allow write: if true;
}
```

### Problem: Data Not Appearing

**Solution**: Check the browser console for errors.

Common issues:
1. Firestore rules not updated
2. Seeding not completed
3. Network/connection issues

Verify seeding:
```typescript
// Check console logs on app startup
// Should see:
// "Seeding physical locations and shelves..."
// "Checking for duplicate parts..."
// "Successfully added X parts to the database"
```

### Problem: References Not Resolving

**Solution**: Ensure seed data completed successfully.

Verify in Firebase Console:
1. Go to Firestore Database
2. Check for `physicalLocations` collection
3. Check for `shelves` collection
4. Verify parts have `physicalLocationRef` and `shelfRef` fields

### Problem: Old Relocations Missing Data

**Solution**: Old relocations use legacy fields, which is expected.

The app handles this automatically:
- New relocations show full relational data
- Old relocations fall back to legacy fields
- Both display correctly in the UI

## 📊 Performance Considerations

### Query Optimization

The relational structure uses efficient querying:

```typescript
// ✅ Optimized - Parallel fetching
const [part, location, shelf] = await Promise.all([
  fetchPart(partId),
  fetchLocation(locationId),
  fetchShelf(shelfId)
]);

// ❌ Slow - Sequential fetching
const part = await fetchPart(partId);
const location = await fetchLocation(locationId);
const shelf = await fetchShelf(shelfId);
```

### Caching

Consider implementing caching for frequently accessed data:

```typescript
// Cache locations (they rarely change)
const locationsCache = new Map();

async function getCachedLocation(id: string) {
  if (!locationsCache.has(id)) {
    const location = await fetchPhysicalLocation(id);
    locationsCache.set(id, location);
  }
  return locationsCache.get(id);
}
```

## 🚀 Future Enhancements

Potential improvements:

1. **User Selection UI**
   - Dropdown for selecting destination location
   - Cascading shelf selection based on location

2. **Validation**
   - Ensure referenced documents exist
   - Prevent invalid references
   - Data integrity constraints

3. **Cascading Updates**
   - Update all parts when location renamed
   - Maintain relocation history

4. **Advanced Querying**
   - Search across related data
   - Complex filtering
   - Aggregation queries

5. **Real-time Updates**
   - Live inventory tracking
   - Notification on relocations
   - Collaborative editing

## 📚 Additional Resources

- [Firebase Relational Structure Documentation](/FIREBASE_RELATIONAL_STRUCTURE.md)
- [Migration Guide](/MIGRATION_GUIDE.md)
- [Firestore Security Rules](/FIRESTORE_SECURITY_RULES.md)
- [Firebase Documentation](https://firebase.google.com/docs/firestore)

## ✅ Summary

The relational database implementation provides:

✅ **Normalized Data** - Proper document references instead of duplication  
✅ **Backwards Compatible** - Works with both old and new data  
✅ **Automatic Seeding** - No manual setup required  
✅ **Type Safe** - Full TypeScript support with interfaces  
✅ **Efficient Queries** - Optimized relational data fetching  
✅ **Easy Migration** - Automatic and manual migration support  
✅ **Well Documented** - Complete documentation and examples  

Your Parts Relocation system is now production-ready! 🎉
