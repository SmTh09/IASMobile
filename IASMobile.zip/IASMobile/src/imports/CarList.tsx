import { useState } from "react";
import svgPaths from "./svg-3zhuzhk3br";
import imgIncadeaLogo1 from "figma:asset/24c902b1a9e277fbde3be49a0758d06802f9c23d.png";
import imgCarRed from "figma:asset/901479a00ad97f34e4ecce86fafd722e5c231ff4.png";
import imgCarGray from "figma:asset/d79143797154b720e7bfa61ecddf09ca1a3e97e3.png";
import imgCar3 from "figma:asset/69bec7266b37b74dca7051ae59a49c1da43b254c.png";
import imgCarOrange from "figma:asset/5757059128b70b795e187f77d09176b243b9cab7.png";
import imgCar6 from "figma:asset/533cb35a4334f4835e80e12e461cc23db8b89e3f.png";
import imgCloseOutline from "figma:asset/30f27ef93d5ac16799250a1a6333c2d9ec116134.png";
import StatusBar from "../components/StatusBar";

// Car data with chassis numbers
const carsData = [
  {
    id: 1,
    plate: "CF-545-YA",
    registrationDate: "25.02.2020",
    brand: "BMW",
    model: "330i xDrive",
    chassis: "WBSWD9C54HP123456",
    image: imgCarRed
  },
  {
    id: 2,
    plate: "TK-271-GT",
    registrationDate: "21.02.2020",
    brand: "BMW",
    model: "540i xDrive",
    chassis: "WBAKB8C51BE252341",
    image: imgCarGray
  },
  {
    id: 3,
    plate: "QX-504-AP",
    registrationDate: "18.02.2020",
    brand: "BMW",
    model: "330I XDRIVE A",
    chassis: "WBA8E5G58HNU12345",
    image: imgCar3
  },
  {
    id: 4,
    plate: "WW-896-BA",
    registrationDate: "01.01.2020",
    brand: "BMW",
    model: "330I XDRIVE A",
    chassis: "5UXFG8C59HLS12345",
    image: imgCarOrange
  },
  {
    id: 6,
    plate: "QR-759-HY",
    registrationDate: "01.01.2020",
    brand: "BMW",
    model: "X6 XDRIVE35I US",
    chassis: "5UXFG435X9L224178",
    image: imgCar6
  }
];

function CloseOutline3() {
  return (
    <img src={imgCloseOutline} alt="" className="w-[16px] h-[16px]" />
  );
}

interface ButtonProps {
  onCancel?: () => void;
}

function Button({ onCancel }: ButtonProps) {
  return (
    <div className="bg-white h-[40px] relative shrink-0 w-[185px] cursor-pointer" data-name="Button" onClick={onCancel}>
      <div className="box-border content-stretch flex h-[40px] items-center justify-between overflow-clip px-[20px] py-0 relative w-[185px]">
        <p className="[white-space-collapse:collapse] font-['IBM_Plex_Sans:Regular',_sans-serif] leading-[normal] not-italic overflow-ellipsis overflow-hidden relative shrink-0 text-[#4c68b0] text-[14px] text-nowrap w-[109px]">Cancel</p>
        <CloseOutline3 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#4c68b0] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

interface BottomBarProps {
  onCancel?: () => void;
}

function BottomBar({ onCancel }: BottomBarProps) {
  return (
    <div className="absolute bg-white box-border content-stretch flex gap-[20px] h-[108px] items-start left-0 overflow-clip p-[20px] w-[430px]" data-name="BottomBar" style={{ top: "calc(80% + 78.4px)" }}>
      <Button onCancel={onCancel} />
      <div className="absolute inset-0 pointer-events-none shadow-[0px_4px_4px_0px_inset_rgba(0,0,0,0.25)]" />
    </div>
  );
}

function Search1() {
  return (
    <div className="h-[16px] relative shrink-0 w-[17px]" data-name="search 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 16">
        <g clipPath="url(#clip0_6_5712)" id="search 1">
          <path d={svgPaths.p39b46880} fill="var(--fill-0, #63646A)" id="Vector" />
          <g id="<Transparent Rectangle>"></g>
        </g>
        <defs>
          <clipPath id="clip0_6_5712">
            <rect fill="white" height="16" width="17" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

interface SearchbarProps {
  searchTerm: string;
  onSearchChange: (value: string) => void;
}

function Searchbar({ searchTerm, onSearchChange }: SearchbarProps) {
  return (
    <div className="absolute bg-[#f4f4f4] h-[31px] left-[20px] w-[390px]" data-name="Searchbar" style={{ top: "calc(20% + 23.6px)" }}>
      <div className="box-border content-stretch flex gap-[20px] h-[31px] items-center overflow-clip px-[20px] py-[10px] relative w-[390px]">
        <Search1 />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search"
          className="font-['IBM_Plex_Sans:Regular',_sans-serif] leading-[normal] not-italic bg-transparent border-none outline-none flex-1 text-[#161616] text-[14px] placeholder:text-[#9b9b9b]"
        />
      </div>
      <div aria-hidden="true" className="absolute border-[#8d8d8d] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function ArrowRight2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="arrow--right 2">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_6_5708)" id="arrow--right 2">
          <path d={svgPaths.pfec3600} fill="var(--fill-0, #525252)" id="Vector" />
          <g id="<Transparent Rectangle>"></g>
        </g>
        <defs>
          <clipPath id="clip0_6_5708">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

interface VehicleCardProps {
  car: typeof carsData[0];
  onSelect?: (car: typeof carsData[0]) => void;
}

function VehicleCard({ car, onSelect }: VehicleCardProps) {
  return (
    <div 
      className="bg-[#f4f4f4] relative shrink-0 w-full cursor-pointer" 
      data-name="Vehicle Card"
      onClick={() => onSelect?.(car)}
    >
      <div className="flex flex-row items-center justify-center overflow-clip size-full">
        <div className="box-border content-stretch flex gap-[20px] items-center justify-center p-[20px] relative w-full">
          <div className="relative shrink-0 size-[100px]" data-name="Car2 2">
            <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={car.image} />
          </div>
          <div className="content-stretch flex flex-col font-['IBM_Plex_Sans:Regular',_sans-serif] gap-[5px] items-start leading-[0] not-italic relative shrink-0 text-[#161616] text-[14px] w-[194px]">
            <p className="leading-[normal] relative shrink-0 w-full">
              <span>{`Plate: `}</span>
              <span className="font-['IBM_Plex_Sans:Light',_sans-serif] not-italic">{car.plate}</span>
            </p>
            <p className="leading-[normal] relative shrink-0 w-full">
              <span>{`Registration Date: `}</span>
              <span className="font-['IBM_Plex_Sans:Light',_sans-serif] not-italic">{car.registrationDate}</span>
            </p>
            <p className="leading-[normal] relative shrink-0 w-full">
              <span>{`Brand: `}</span>
              <span className="font-['IBM_Plex_Sans:Light',_sans-serif] not-italic">{car.brand}</span>
            </p>
            <p className="leading-[normal] relative shrink-0 w-full">
              <span>{`Model: `}</span>
              <span className="font-['IBM_Plex_Sans:Light',_sans-serif] not-italic">{car.model}</span>
            </p>
          </div>
          <ArrowRight2 />
        </div>
      </div>
    </div>
  );
}

interface Frame869Props {
  filteredCars: typeof carsData;
  onSelectCar?: (car: typeof carsData[0]) => void;
}

function Frame869({ filteredCars, onSelectCar }: Frame869Props) {
  return (
    <div className="absolute content-stretch flex flex-col gap-[10px] h-[568px] items-start left-[20px] overflow-x-clip overflow-y-auto w-[390px]" style={{ top: "calc(20% + 69.6px)" }}>
      {filteredCars.map((car) => (
        <VehicleCard key={car.id} car={car} onSelect={onSelectCar} />
      ))}
    </div>
  );
}

function Search2() {
  return (
    <div className="absolute left-[332px] size-[32px] top-[7px]" data-name="search 1">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g clipPath="url(#clip0_1_864)" id="search 1">
          <path d={svgPaths.p2c8f5f80} fill="var(--fill-0, #63646A)" id="Vector" />
          <g id="<Transparent Rectangle>"></g>
        </g>
        <defs>
          <clipPath id="clip0_1_864">
            <rect fill="white" height="32" width="32" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Menu1({ onClick }: { onClick?: () => void }) {
  return (
    <div className="absolute left-0 size-[32px] top-[7px] cursor-pointer" data-name="menu 1" onClick={onClick}>
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g clipPath="url(#clip0_1_857)" id="menu 1">
          <path d="M28 6H4V8H28V6Z" fill="var(--fill-0, #63646A)" id="Vector" />
          <path d="M28 24H4V26H28V24Z" fill="var(--fill-0, #63646A)" id="Vector_2" />
          <path d="M28 12H4V14H28V12Z" fill="var(--fill-0, #63646A)" id="Vector_3" />
          <path d="M28 18H4V20H28V18Z" fill="var(--fill-0, #63646A)" id="Vector_4" />
          <g id="<Transparent Rectangle>"></g>
        </g>
        <defs>
          <clipPath id="clip0_1_857">
            <rect fill="white" height="32" width="32" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Frame10({ onMenuClick }: { onMenuClick?: () => void }) {
  return (
    <div className="absolute h-[45.714px] left-[33px] top-[7px] w-[364px]">
      <div className="absolute h-[45.714px] left-[66px] top-0 w-[100px]" data-name="incadea_logo 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgIncadeaLogo1} />
      </div>
      <Search2 />
      <Menu1 onClick={onMenuClick} />
    </div>
  );
}

function TopBar({ onMenuClick }: { onMenuClick?: () => void }) {
  return (
    <div className="absolute h-[60px] left-0 top-[59px] w-[430px]" data-name="TopBar">
      <div aria-hidden="true" className="absolute border-[#3d538d] border-[0px_0px_10px] border-solid inset-0 pointer-events-none" />
      <div className="absolute bg-white h-[60px] left-0 pointer-events-none top-0 w-[430px]">
        <div aria-hidden="true" className="absolute border-[#63646a] border-[0px_0px_1px] border-solid inset-0" />
        <div className="absolute inset-0 shadow-[0px_4px_4px_0px_inset_rgba(0,0,0,0.25)]" />
      </div>
      <Frame10 onMenuClick={onMenuClick} />
    </div>
  );
}

function Time() {
  return (
    <div className="h-[13px] relative shrink-0 w-[40px]" data-name="Time">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 40 13">
        <g clipPath="url(#clip0_1_811)" id="Time">
          <path d={svgPaths.p694a000} fill="var(--fill-0, black)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_811">
            <rect fill="white" height="13" width="40" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Time1() {
  return (
    <div className="basis-0 bg-[rgba(255,255,255,0.8)] content-stretch flex grow h-[59px] items-center justify-center min-h-px min-w-px overflow-clip relative shrink-0" data-name="Time">
      <Time />
    </div>
  );
}

function DynamicIslandFrame() {
  return (
    <div className="basis-0 bg-[rgba(255,255,255,0.8)] content-stretch flex grow h-[59px] items-center justify-center min-h-px min-w-px overflow-clip relative shrink-0" data-name="Dynamic Island Frame">
      <div className="bg-black h-[37px] rounded-[20px] shrink-0 w-[125px]" data-name="Dynamic Island" />
    </div>
  );
}

function Reception() {
  return (
    <div className="h-[12px] relative shrink-0 w-[18px]" data-name="Reception">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 12">
        <g clipPath="url(#clip0_1_837)" id="Reception">
          <path d={svgPaths.p1ec31400} fill="var(--fill-0, black)" id="Vector" />
          <path d={svgPaths.p19f8d480} fill="var(--fill-0, black)" id="Vector_2" />
          <path d={svgPaths.p13f4aa00} fill="var(--fill-0, black)" id="Vector_3" />
          <path d={svgPaths.p1bfb7500} fill="var(--fill-0, black)" id="Vector_4" />
        </g>
        <defs>
          <clipPath id="clip0_1_837">
            <rect fill="white" height="12" width="18" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function WiFi() {
  return (
    <div className="h-[12px] relative shrink-0 w-[18px]" data-name="Wi-fi">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 12">
        <g clipPath="url(#clip0_1_818)" id="Wi-fi">
          <path clipRule="evenodd" d={svgPaths.p2952ae40} fill="var(--fill-0, black)" fillRule="evenodd" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_818">
            <rect fill="white" height="12" width="18" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Battery() {
  return (
    <div className="h-[13px] relative shrink-0 w-[28px]" data-name="Battery">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 13">
        <g clipPath="url(#clip0_1_806)" id="Battery">
          <path d={svgPaths.p3689d180} id="Vector" opacity="0.35" stroke="var(--stroke-0, black)" />
          <path d={svgPaths.p2a8bd780} fill="var(--fill-0, black)" id="Vector_2" opacity="0.4" />
          <path d={svgPaths.p39726670} fill="var(--fill-0, black)" id="Vector_3" />
        </g>
        <defs>
          <clipPath id="clip0_1_806">
            <rect fill="white" height="13" width="28" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Icons() {
  return (
    <div className="basis-0 bg-[rgba(255,255,255,0.8)] content-stretch flex gap-[8px] grow h-[59px] items-center justify-center min-h-px min-w-px overflow-clip relative shrink-0" data-name="Icons">
      <Reception />
      <WiFi />
      <Battery />
    </div>
  );
}

function StatusBar() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.8)] content-stretch flex h-[59px] items-center justify-center left-0 overflow-clip right-0 top-0" data-name="Status Bar">
      <Time1 />
      <DynamicIslandFrame />
      <Icons />
    </div>
  );
}

function HomeBar() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0)] box-border content-stretch flex h-[34px] items-center justify-center left-0 overflow-clip pb-0 pt-[13px] px-0 right-0" data-name="Home Bar" style={{ top: "calc(100% - 34px)" }}>
      <div className="bg-black h-[5px] rounded-[3px] shrink-0 w-[134px]" data-name="Rectangle" />
    </div>
  );
}

export type CarData = typeof carsData[0];

interface CarListProps {
  onCancel?: () => void;
  onSelectCar?: (car: CarData) => void;
  onMenuClick?: () => void;
}

export default function CarList({ onCancel, onSelectCar, onMenuClick }: CarListProps) {
  const [searchTerm, setSearchTerm] = useState("");

  // Filter cars by chassis number OR plate number
  const filteredCars = carsData.filter((car) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      car.chassis.toLowerCase().includes(searchLower) ||
      car.plate.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="bg-white relative size-full" data-name="Car List">
      <StatusBar />
      <HomeBar />
      <p className="absolute font-['IBM_Plex_Sans:Regular',_sans-serif] leading-[normal] left-[20px] not-italic text-[#161616] text-[24px] text-nowrap top-[159px] whitespace-pre">{`Select a vehicle `}</p>
      <BottomBar onCancel={onCancel} />
      <Searchbar searchTerm={searchTerm} onSearchChange={setSearchTerm} />
      <Frame869 filteredCars={filteredCars} onSelectCar={onSelectCar} />
      <TopBar onMenuClick={onMenuClick} />
    </div>
  );
}
