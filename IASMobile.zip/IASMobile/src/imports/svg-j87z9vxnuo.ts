export default {
pa88e080: "M11 8L6 13L5.3 12.3L9.6 8L5.3 3.7L6 3L11 8Z",
}
