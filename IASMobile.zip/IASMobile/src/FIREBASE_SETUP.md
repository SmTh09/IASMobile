# 🔥 Firebase Setup Guide

Your app is now configured to use **Firebase Firestore** for real structured database storage!

## ✅ What's Already Done

- ✅ Firebase SDK integrated
- ✅ Firestore functions created
- ✅ API layer updated to use Firebase
- ✅ All CRUD operations implemented
- ✅ Appointment counting system ready

## 🚀 Setup Instructions

### Step 1: Create a Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click **"Add project"**
3. Enter a project name (e.g., "Incadea Appointments")
4. Accept terms and click **"Continue"**
5. Choose whether to enable Google Analytics (optional)
6. Click **"Create project"**

### Step 2: Register Your Web App

1. In your Firebase project, click the **Web icon** (`</>`) to add a web app
2. Enter an app nickname (e.g., "Appointment Booking App")
3. Click **"Register app"**
4. Copy the `firebaseConfig` object that appears

### Step 3: Add Firebase Configuration

1. Open `/utils/firebase/config.ts` in your code
2. Replace the placeholder values with your Firebase config:

```typescript
export const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "your-project-id.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project-id.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef123456"
};
```

### Step 4: Enable Firestore Database

1. In Firebase Console, go to **Build → Firestore Database**
2. Click **"Create database"**
3. Choose **"Start in test mode"** (for development)
   - ⚠️ **Important**: This allows read/write access for 30 days
   - You'll need to secure it before production!
4. Select a Cloud Firestore location (choose closest to your users)
5. Click **"Enable"**

### Step 5: Configure Security Rules (CRITICAL!)

⚠️ **If you get "permission-denied" errors**, you need to update your security rules!

1. Go to **Firestore Database → Rules** tab
2. Replace the content with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // TEST MODE - Allow all operations during development
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

3. Click **"Publish"**

📖 **See `/FIRESTORE_SECURITY_RULES.md` for more secure production rules!**

### Step 6: Test the Connection

1. Save your changes to `/utils/firebase/config.ts`
2. Refresh your app
3. Try creating a new appointment
4. Check Firebase Console → Firestore Database to see your data!

## 📊 Database Structure

Firebase will automatically create these collections:

### `appointments` Collection
```
appointments/
  └── {appointmentId}/
      ├── id: string
      ├── customerId: string
      ├── customerName: string
      ├── vehicle: object
      │   ├── licensePlate: string
      │   ├── brand: string
      │   ├── model: string
      │   └── image: string
      ├── jobLines: array
      │   └── [{ id: number, text: string }]
      ├── mileage: string
      ├── measurement: string
      ├── date: string (ISO format)
      ├── timeSlot: string
      ├── status: string (default: "pending")
      ├── createdAt: string (ISO timestamp)
      └── updatedAt?: string (ISO timestamp)
```

### `appointmentCounts` Collection
```
appointmentCounts/
  └── {customerId}/
      ├── customerId: string
      └── count: number
```

## 🔒 Security Rules (Production)

Before going to production, update your Firestore Security Rules:

1. Go to **Firestore Database → Rules**
2. Replace with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Allow read/write to appointments for authenticated users
    match /appointments/{appointmentId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    
    // Allow read/write to appointment counts
    match /appointmentCounts/{customerId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    
    // For now, allow all operations (TEST MODE ONLY)
    // match /{document=**} {
    //   allow read, write: if true;
    // }
  }
}
```

3. Click **"Publish"**

## 🎯 Features Available

Your app now has:

- ✅ **Create appointments** with full details
- ✅ **Read appointments** filtered by customer
- ✅ **Update appointment status** 
- ✅ **Delete appointments**
- ✅ **Track appointment counts** per customer
- ✅ **Real-time data sync** (Firebase feature)
- ✅ **Automatic indexing** for queries
- ✅ **Scalable cloud database**

## 🛠️ Advanced Features (Optional)

### Add Firebase Authentication

To add user login:

1. Enable Authentication in Firebase Console
2. Choose sign-in methods (Email/Password, Google, etc.)
3. Implement auth in your app

### Add Real-time Listeners

Instead of fetching data, listen to changes:

```typescript
import { onSnapshot } from 'firebase/firestore';

const unsubscribe = onSnapshot(appointmentsQuery, (snapshot) => {
  const appointments = snapshot.docs.map(doc => doc.data());
  // Update UI automatically when data changes
});
```

### Add Cloud Functions

Create server-side logic that triggers on database events:

```typescript
// Example: Send email when appointment created
exports.onAppointmentCreated = functions.firestore
  .document('appointments/{appointmentId}')
  .onCreate((snap, context) => {
    // Send confirmation email
  });
```

## 📝 Data Management

### View Your Data
- Go to Firebase Console → Firestore Database
- Browse collections and documents
- Edit data directly in the console

### Export Data
- Firebase Console → Firestore → Export/Import
- Or use Firebase Admin SDK

### Backup Strategy
- Enable automatic backups in Firebase Console
- Export important data regularly

## 🐛 Troubleshooting

### Error: "Firebase: Error (auth/api-key-not-valid)"
- Check that your `apiKey` is correct in `/utils/firebase/config.ts`

### Error: "Missing or insufficient permissions"
- Your Firestore Security Rules are too restrictive
- Set to test mode or implement proper authentication

### Error: "Firebase: Firebase App named '[DEFAULT]' already exists"
- You're initializing Firebase twice
- This is handled automatically in the code

### No data appearing in Firestore
- Check browser console for errors
- Verify Firestore is enabled in Firebase Console
- Check Security Rules allow write access

## 📚 Resources

- [Firebase Documentation](https://firebase.google.com/docs)
- [Firestore Quickstart](https://firebase.google.com/docs/firestore/quickstart)
- [Security Rules Guide](https://firebase.google.com/docs/firestore/security/get-started)
- [Pricing Information](https://firebase.google.com/pricing)

## 💰 Pricing Notes

Firebase Free Tier includes:
- 1 GB storage
- 50,000 reads/day
- 20,000 writes/day
- 20,000 deletes/day

This is more than enough for prototyping and small apps! 🎉

---

## ✨ You're All Set!

Once you add your Firebase credentials, your app will automatically save all appointments to Firebase Firestore!
