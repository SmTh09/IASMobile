# Parts Relocation Submission Flow

## Overview
This document describes the complete submission flow for the New Parts Relocation feature, including validation, database operations, and inventory management.

## Pre-Submission Validation

### Submit Button Enable/Disable Logic
The "Submit" button remains **disabled** until ALL of the following conditions are met:

1. ✅ A part is selected (`selectedPart` exists)
2. ✅ A valid quantity is entered:
   - Greater than 0
   - Less than or equal to current available stock
   - No quantity error present
3. ✅ A new shelf is selected (`selectedShelfId` exists)
4. ✅ The new shelf is **different** from the current shelf
5. ✅ No part validation errors exist
6. ✅ Not currently submitting

### Visual States
- **Disabled**: `bg-[#c6c6c6]` with gray text `text-[#8d8d8d]`
- **Enabled**: `bg-[#4c68b0]` with white text `text-white`

## Submission Process

### Step 1: Final Validation
Before submission, the system performs these validations:

```typescript
// Part relocatability check
const partError = getPartRelocationError(selectedPart);
if (partError) {
  setPartValidationError(partError);
  return;
}

// Quantity validation
if (qty <= 0 || qty > available) {
  setQuantityError("Invalid quantity");
  return;
}

// Same shelf validation
if (fromShelfId === toShelfId) {
  setPartValidationError("Cannot relocate to the same shelf");
  return;
}
```

### Step 2: Database Operations (Atomic)
The relocation uses Firebase batch writes to ensure atomicity:

#### 2.1 Create Relocation Record
Creates a new document in the `relocations` collection:

```javascript
{
  partRef: DocumentReference,           // Reference to parts/{partId}
  partNumber: string,                   // e.g., "WH340"
  partName: string,                     // e.g., "ALL TERRAIN WHEEL"
  fromShelfRef: DocumentReference,      // Reference to shelves/{fromShelfId}
  fromShelfLabel: string,               // e.g., "B1"
  toShelfRef: DocumentReference,        // Reference to shelves/{toShelfId}
  toShelfLabel: string,                 // e.g., "B7"
  quantityRelocated: number,            // e.g., 5
  physicalLocationRef: DocumentReference, // Reference to physicalLocations/{locationId}
  timestamp: Timestamp,                 // Server timestamp
  userRef: null                         // Optional: user tracking
}
```

#### 2.2 Update Source Part Inventory
Decreases the `currentAvailability` on the original part document:

```javascript
// Before: currentAvailability = 30
// After relocating 5 units
// After: currentAvailability = 25
```

#### 2.3 Update Target Shelf Inventory
Two scenarios:

**A. Part already exists on target shelf:**
```javascript
// Find existing part on target shelf
// Increase its currentAvailability by relocated quantity
targetPart.currentAvailability += quantityRelocated;
```

**B. Part doesn't exist on target shelf:**
```javascript
// Create new part document
{
  partNumber: "WH340",
  partName: "ALL TERRAIN WHEEL",
  physicalLocationRef: DocumentReference,
  physicalLocation: "BMW Parts",
  shelfRef: toShelfRef,
  shelfAddress: "B7",
  currentAvailability: 5,  // Initial quantity = relocated amount
  quantity: 5
}
```

### Step 3: Success Handling
After successful relocation:

1. ✅ Show success toast: "Relocation successfully created."
2. ✅ Clear all form fields
3. ✅ Clear selected part
4. ✅ Navigate back to Parts Relocation list after 500ms delay

### Step 4: Error Handling
If any error occurs:

1. ❌ Show error toast with specific message
2. ❌ Set validation error message
3. ❌ Keep form data intact for correction
4. ❌ Re-enable submit button after error cleared

## Example Workflow

### Complete Example
```
Initial State:
- Part: WH340 (ALL TERRAIN WHEEL)
- Current Shelf: B1
- Current Availability: 30 units

User Actions:
1. Enters quantity: 10
2. Selects new shelf: B7
3. Clicks Submit

Database Changes:
1. New relocation document created
2. Part on B1: currentAvailability 30 → 20
3. Part on B7 (if exists): currentAvailability X → X+10
   OR Part on B7 (if new): currentAvailability = 10

Result:
- B1 has 20 units
- B7 has 10 units (new) or X+10 units (existing)
- Total system inventory remains constant
```

## Validation Rules Summary

| Rule | Validation | Error Message |
|------|-----------|---------------|
| Quantity > 0 | `qty > 0` | "Please enter a valid quantity." |
| Quantity ≤ Available | `qty <= currentAvailability` | "The quantity to relocate cannot exceed the current available stock." |
| Shelf Selected | `selectedShelfId !== ""` | Submit button disabled |
| Different Shelf | `fromShelfId !== toShelfId` | "Cannot relocate to the same shelf." |
| Part Relocatable | `isPartRelocatable(part)` | Part-specific validation message |

## Toast Notifications

### Success Toast
```javascript
toast.success('Relocation successfully created.', {
  duration: 3000,
});
```

### Error Toast
```javascript
toast.error('Failed to create relocation. Please try again.', {
  duration: 4000,
});
```

## File Structure

### Core Files
- `/utils/firebase/relocations.ts` - Relocation logic and inventory updates
- `/components/NewPartsRelocation.tsx` - UI and submission handler
- `/utils/firebase/partValidation.ts` - Part validation rules
- `/utils/firebase/relationalData.ts` - Data fetching utilities

### Database Collections
- `relocations` - Relocation history
- `parts` - Part inventory
- `shelves` - Shelf information
- `physicalLocations` - Physical location data

## Testing Scenarios

### Happy Path
1. ✅ Select part with 30 units on B1
2. ✅ Enter quantity: 10
3. ✅ Select shelf: B7
4. ✅ Submit succeeds
5. ✅ B1 = 20, B7 = 10
6. ✅ Success toast shown
7. ✅ Returns to list

### Error Scenarios
1. ❌ Quantity = 50 (> 30 available) → Error toast
2. ❌ Quantity = 0 → Error message
3. ❌ Same shelf (B1 → B1) → Error toast
4. ❌ No shelf selected → Button disabled
5. ❌ Network error → Error toast

## Design Consistency
- Uses existing BottomBar component
- Maintains IBM Plex Sans typography
- Follows #4C68B0 (enabled) / #C6C6C6 (disabled) color scheme
- iOS-style status bar and home bar
- Consistent with Figma design specifications
