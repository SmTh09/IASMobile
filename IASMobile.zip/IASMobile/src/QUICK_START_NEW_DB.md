# Quick Start - New Database Structure

## 🚀 One-Click Migration

1. **Load the app** in your browser
2. **Look for the red button** in the bottom-right corner: "🔄 Migrate Database"
3. **Click it** and confirm
4. **Wait** for success message
5. **Refresh** the page
6. **Done!** ✅

## ✅ What You Get

### Physical Locations (2)
- BMW Parts
- Main Warehouse

### Shelves (15)
- **BMW Parts:** A1, A2, B1-B7, C1-C2, D1-D2, DEFB
- **Main Warehouse:** BK1

### Parts (4)
1. **83210398511** - test package part (BMW Parts, DEFB, qty: 56)
2. **11227508000** - New Test Part (BMW Parts, DEFB, qty: 17)
3. **11427512300** - SET OIL-FILTER ELEMENT (BMW Parts, B3, qty: 27)
4. **WH340** - ALL TERRAIN WHEEL (Multiple locations and shelves)
   - BMW Parts: B1(30), B2(35), B3(25), B4(20), B6(34), B7(15)
   - Main Warehouse: BK1(50)

## 🎯 Key Features

### Multi-Location Support
Parts can exist in multiple physical locations with different shelves in each location.

### Location Boundaries
Relocations can only happen within the same physical location. You can't move parts from BMW Parts to Main Warehouse via relocation.

### Normalized Data
- Each physical location is stored once
- Each shelf belongs to one location
- Parts reference locations and shelves by ID
- Clean, maintainable structure

## 🧪 Quick Test

1. Go to **Parts Relocation** → **+ New**
2. Click **Add Part**
3. Select **WH340** from **shelf B1**
4. Notice the dropdown only shows B2, B3, B4, B6, B7 (same location)
5. Enter quantity (max 30)
6. Confirm and Submit
7. Check the relocation list ✅

## ⚠️ Important

- **This deletes all existing data**
- **No automatic backup** - back up manually first if needed
- **One-way migration** - can't auto-revert
- **Test in development first** before production

## 📖 Full Documentation

See `/DATABASE_MIGRATION_INSTRUCTIONS.md` for detailed information.

## 🐛 Troubleshooting

**Button not showing?**
→ Check console for errors, refresh page

**Migration fails?**
→ Check Firebase permissions in Firebase Console

**Data doesn't appear?**
→ Refresh page, clear cache

**Need help?**
→ Check browser console and Firebase Console Firestore tab
