# Migration Guide: Legacy to Relational Structure

## Overview

This guide explains how to migrate existing Parts Relocation data from the legacy structure to the new relational structure.

## What Changed?

### Before (Legacy)
```json
{
  "parts": {
    "part001": {
      "partNumber": "83210398511",
      "partName": "test package part",
      "physicalLocation": "BMW Parts",
      "shelfAddress": "DEFB",
      "currentAvailability": 56
    }
  },
  "relocations": {
    "reloc001": {
      "partNumber": "83210398511",
      "fromLocation": "BMW Parts",
      "toLocation": "Main Warehouse",
      "fromShelf": "DEFB",
      "toShelf": "A1"
    }
  }
}
```

### After (Relational)
```json
{
  "physicalLocations": {
    "bmwParts": {
      "name": "BMW Parts",
      "address": "Warehouse A - Section B"
    }
  },
  "shelves": {
    "shelfDEFB": {
      "label": "DEFB",
      "physicalLocationRef": "bmwParts"
    }
  },
  "parts": {
    "part001": {
      "partNumber": "83210398511",
      "partName": "test package part",
      "physicalLocationRef": "bmwParts",
      "shelfRef": "shelfDEFB",
      "physicalLocation": "BMW Parts",  // Kept for backwards compatibility
      "shelfAddress": "DEFB",           // Kept for backwards compatibility
      "currentAvailability": 56
    }
  },
  "relocations": {
    "reloc001": {
      "partRef": "part001",
      "fromLocationRef": "bmwParts",
      "toLocationRef": "mainWarehouse",
      "fromShelfRef": "shelfDEFB",
      "toShelfRef": "shelfA1",
      "partNumber": "83210398511",      // Kept for backwards compatibility
      "fromLocation": "BMW Parts",      // Kept for backwards compatibility
      "toLocation": "Main Warehouse"    // Kept for backwards compatibility
    }
  }
}
```

## Automatic Migration

The app automatically handles migration on first load:

1. **Seeds Locations & Shelves**: Creates `physicalLocations` and `shelves` collections
2. **Seeds Parts**: Creates new parts with both reference and legacy fields
3. **New Relocations**: Automatically created with references
4. **Old Data**: Remains accessible via legacy fields

## Manual Migration (Optional)

If you have existing data that needs to be migrated:

### Step 1: Backup Your Data

Always backup before migrating:

```bash
# Using Firebase CLI
firebase firestore:export gs://your-bucket/backups/$(date +%Y%m%d)
```

### Step 2: Seed Base Collections

Run this in your app console:

```javascript
import { seedLocationsAndShelves } from './utils/firebase/seedLocationsAndShelves';

// Seed locations and shelves
await seedLocationsAndShelves();
```

### Step 3: Update Existing Parts

Create a migration script to add references to existing parts:

```typescript
import { collection, getDocs, doc, updateDoc } from "firebase/firestore";
import { db } from "./utils/firebase/firestore";

async function migrateParts() {
  const partsRef = collection(db, "parts");
  const snapshot = await getDocs(partsRef);
  
  const updates = snapshot.docs.map(async (partDoc) => {
    const data = partDoc.data();
    
    // Map location name to location ID
    const locationMap: { [key: string]: string } = {
      "BMW Parts": "bmwParts",
      "Main Warehouse": "mainWarehouse"
    };
    
    // Map shelf label to shelf ID
    const shelfMap: { [key: string]: string } = {
      "DEFB": "shelfDEFB",
      "B1": "shelfB1",
      "B2": "shelfB2",
      "B3": "shelfB3",
      "B6": "shelfB6",
      "A1": "shelfA1",
      "A2": "shelfA2",
      "C1": "shelfC1"
    };
    
    const updates: any = {};
    
    // Add location reference
    if (data.physicalLocation && !data.physicalLocationRef) {
      updates.physicalLocationRef = locationMap[data.physicalLocation] || "bmwParts";
    }
    
    // Add shelf reference
    if (data.shelfAddress && !data.shelfRef) {
      updates.shelfRef = shelfMap[data.shelfAddress] || "shelfDEFB";
    }
    
    // Only update if we have new fields to add
    if (Object.keys(updates).length > 0) {
      await updateDoc(doc(db, "parts", partDoc.id), updates);
      console.log(`Updated part ${partDoc.id}`);
    }
  });
  
  await Promise.all(updates);
  console.log("Parts migration complete");
}

// Run the migration
migrateParts();
```

### Step 4: Update Existing Relocations

Create a migration script for relocations:

```typescript
import { collection, getDocs, doc, updateDoc } from "firebase/firestore";
import { db } from "./utils/firebase/firestore";

async function migrateRelocations() {
  const relocationsRef = collection(db, "relocations");
  const snapshot = await getDocs(relocationsRef);
  
  const locationMap: { [key: string]: string } = {
    "BMW Parts": "bmwParts",
    "Main Warehouse": "mainWarehouse"
  };
  
  const shelfMap: { [key: string]: string } = {
    "DEFB": "shelfDEFB",
    "B1": "shelfB1",
    "B2": "shelfB2",
    "B3": "shelfB3",
    "B6": "shelfB6",
    "A1": "shelfA1",
    "A2": "shelfA2",
    "C1": "shelfC1"
  };
  
  const updates = snapshot.docs.map(async (relDoc) => {
    const data = relDoc.data();
    
    const updates: any = {};
    
    // Add reference fields if they don't exist
    if (data.partId && !data.partRef) {
      updates.partRef = data.partId;
    }
    
    if (data.fromLocation && !data.fromLocationRef) {
      updates.fromLocationRef = locationMap[data.fromLocation] || "bmwParts";
    }
    
    if (data.toLocation && !data.toLocationRef) {
      updates.toLocationRef = locationMap[data.toLocation] || "mainWarehouse";
    }
    
    if (data.fromShelf && !data.fromShelfRef) {
      updates.fromShelfRef = shelfMap[data.fromShelf] || "shelfDEFB";
    }
    
    if (data.toShelf && !data.toShelfRef) {
      updates.toShelfRef = shelfMap[data.toShelf] || "shelfA1";
    }
    
    // Add date if missing
    if (!data.date) {
      updates.date = data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString();
    }
    
    // Add status if missing
    if (!data.status) {
      updates.status = "activated";
    }
    
    // Only update if we have new fields to add
    if (Object.keys(updates).length > 0) {
      await updateDoc(doc(db, "relocations", relDoc.id), updates);
      console.log(`Updated relocation ${relDoc.id}`);
    }
  });
  
  await Promise.all(updates);
  console.log("Relocations migration complete");
}

// Run the migration
migrateRelocations();
```

## Backwards Compatibility

The new system maintains full backwards compatibility:

### Reading Data
- Components check for reference fields first
- Fall back to legacy fields if references don't exist
- Both old and new data formats work seamlessly

### Writing Data
- All new relocations include both reference and legacy fields
- Existing code continues to work without modification

### Query Optimization
- New queries use relational fetching for better performance
- Legacy queries still work for older data

## Verification

After migration, verify data integrity:

```typescript
import { fetchAllRelocationsWithRelations } from './utils/firebase/relationalData';

async function verifyMigration() {
  const relocations = await fetchAllRelocationsWithRelations();
  
  relocations.forEach((rel) => {
    console.log('Relocation:', rel.id);
    console.log('  Part:', rel.partData?.partNumber);
    console.log('  From:', rel.fromLocationData?.name, '/', rel.fromShelfData?.label);
    console.log('  To:', rel.toLocationData?.name, '/', rel.toShelfData?.label);
    console.log('  Status:', rel.status);
    console.log('---');
  });
  
  console.log(`Total relocations: ${relocations.length}`);
}

verifyMigration();
```

## Rollback Plan

If you need to rollback:

1. **Restore from backup**:
   ```bash
   firebase firestore:import gs://your-bucket/backups/YYYYMMDD
   ```

2. **Or manually remove reference fields**:
   - The legacy fields are still present
   - Remove the new collections if needed
   - App will continue to work with legacy data

## Performance Considerations

### Before Migration
- Simple queries, but denormalized data
- Lots of duplicate information
- Difficult to maintain consistency

### After Migration
- Normalized data structure
- Better data integrity
- More complex queries but with better caching
- Easier to maintain and extend

## Support

For issues or questions:

1. Check the console for error messages
2. Verify Firestore security rules include new collections
3. Review `/FIREBASE_RELATIONAL_STRUCTURE.md` for details
4. Check that seed data completed successfully

## Next Steps

After migration:

1. ✅ Test all parts relocation functionality
2. ✅ Verify data appears correctly in the UI
3. ✅ Monitor Firebase console for any errors
4. ✅ Update security rules for production (see `/FIRESTORE_SECURITY_RULES.md`)
5. ✅ Consider implementing user-based location selection
6. ✅ Add validation for reference integrity
