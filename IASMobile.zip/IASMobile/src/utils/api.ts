// ==========================================
// BACKEND CONFIGURATION
// ==========================================
// This app supports both Firebase and Supabase backends
// Configure Firebase in: /utils/firebase/config.ts
// If Firebase is not configured, it will automatically use Supabase

import { isFirebaseConfigured } from './firebase/config';
import * as firestore from './firebase/firestore';
import { projectId, publicAnonKey } from './supabase/info';

const USE_FIREBASE = isFirebaseConfigured();
const SUPABASE_API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-24861ad3`;

// Log which backend is being used
if (USE_FIREBASE) {
  console.log('🔥 Using Firebase Firestore backend');
} else {
  console.log('📦 Using Supabase backend (Firebase not configured)');
}

interface AppointmentData {
  customerId: string;
  customerName: string;
  vehicle: {
    licensePlate: string;
    brand: string;
    model: string;
    image: string;
  };
  jobLines: Array<{ id: number; text: string }>;
  mileage: string;
  measurement: string;
  date: string;
  timeSlot: string;
}

// Helper function for Supabase API calls
async function supabaseFetch(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${SUPABASE_API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
      ...options.headers,
    },
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  const data = await response.json();
  
  if (data.success === false) {
    throw new Error(data.error || 'API request failed');
  }

  return data;
}

export async function createAppointment(appointmentData: AppointmentData) {
  try {
    if (USE_FIREBASE) {
      return await firestore.createAppointment(appointmentData);
    } else {
      return await supabaseFetch('/appointments', {
        method: 'POST',
        body: JSON.stringify(appointmentData)
      });
    }
  } catch (error) {
    console.error('Error in createAppointment:', error);
    throw error;
  }
}

export async function getAppointments(customerId: string) {
  try {
    if (USE_FIREBASE) {
      return await firestore.getAppointments(customerId);
    } else {
      const data = await supabaseFetch(`/appointments/${customerId}`);
      return data.appointments || [];
    }
  } catch (error) {
    console.error('Error in getAppointments:', error);
    throw error;
  }
}

export async function getAppointmentCount(customerId: string) {
  try {
    if (USE_FIREBASE) {
      return await firestore.getAppointmentCount(customerId);
    } else {
      const data = await supabaseFetch(`/appointments/${customerId}/count`);
      return data.count || 0;
    }
  } catch (error) {
    console.error('Error in getAppointmentCount:', error);
    // Return 0 on error instead of throwing - graceful degradation
    return 0;
  }
}

export async function updateAppointmentStatus(
  customerId: string, 
  appointmentId: string, 
  status: string
) {
  try {
    if (USE_FIREBASE) {
      const result = await firestore.updateAppointmentStatus(appointmentId, status);
      return result.appointment;
    } else {
      const data = await supabaseFetch(`/appointments/${customerId}/${appointmentId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      return data.appointment;
    }
  } catch (error) {
    console.error('Error in updateAppointmentStatus:', error);
    throw error;
  }
}

export async function deleteAppointment(customerId: string, appointmentId: string) {
  try {
    if (USE_FIREBASE) {
      return await firestore.deleteAppointment(customerId, appointmentId);
    } else {
      const data = await supabaseFetch(`/appointments/${customerId}/${appointmentId}`, {
        method: 'DELETE'
      });
      return data.appointmentCount || 0;
    }
  } catch (error) {
    console.error('Error in deleteAppointment:', error);
    throw error;
  }
}
